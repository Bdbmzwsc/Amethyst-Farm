package com.zsj.amethystfarm.util;

import java.util.Set;
import java.util.function.Consumer;
import java.util.function.LongConsumer;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_3218;

public final class NbtCompat {
    private NbtCompat() {}

    public static void readString(class_2487 tag, String key, Consumer<String> consumer) {
        //? if >=1.21.5 {
        /*tag.getString(key).ifPresent(consumer);
        *///?} else {
        if (tag.method_10545(key)) {
            consumer.accept(tag.method_10558(key));
        }
        //?}
    }

    public static void readLong(class_2487 tag, String key, LongConsumer consumer) {
        //? if >=1.21.5 {
        /*tag.getLong(key).ifPresent(value -> consumer.accept(value));
        *///?} else {
        if (tag.method_10545(key)) {
            consumer.accept(tag.method_10537(key));
        }
        //?}
    }

    public static boolean readBoolean(class_2487 tag, String key, boolean defaultValue) {
        //? if >=1.21.5 {
        /*return tag.getBoolean(key).orElse(defaultValue);
        *///?} else {
        return tag.method_10545(key) ? tag.method_10577(key) : defaultValue;
         //?}
    }

    public static void readCompound(class_2487 tag, String key, Consumer<class_2487> consumer) {
        //? if >=1.21.5 {
        /*tag.getCompound(key).ifPresent(consumer);
        *///?} else {
        if (tag.method_10545(key)) {
            consumer.accept(tag.method_10562(key));
        }
        //?}
    }

    public static class_2487 readCompoundOrEmpty(class_2487 tag, String key) {
        //? if >=1.21.5 {
        /*return tag.getCompound(key).orElse(new CompoundTag());
        *///?} else {
        return tag.method_10545(key) ? tag.method_10562(key) : new class_2487();
         //?}
    }

    public static Set<String> tagKeys(class_2487 tag) {
        //? if >=1.21.5 {
        /*return tag.keySet();
        *///?} else {
        return tag.method_10541();
         //?}
    }

    public static int worldTopY(class_3218 level) {
        //? if >=1.21.5 {
        /*return level.getMaxY();
        *///?} else {
        return level.method_8597().comp_652() - 1;
         //?}
    }

    public static class_2350 directionFromDelta(double x, double y, double z) {
        //? if >=1.21.4 {
        return class_2350.method_10142(x, y, z);
        //?} else {
        /*double ax = Math.abs(x);
        double ay = Math.abs(y);
        double az = Math.abs(z);
        if (ax > ay && ax > az) {
            return x > 0 ? Direction.EAST : Direction.WEST;
        }
        if (ay > az) {
            return y > 0 ? Direction.UP : Direction.DOWN;
        }
        return z > 0 ? Direction.SOUTH : Direction.NORTH;
         *///?}
    }
}
