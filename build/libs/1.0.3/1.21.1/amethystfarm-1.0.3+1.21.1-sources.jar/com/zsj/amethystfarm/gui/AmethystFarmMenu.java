package com.zsj.amethystfarm.gui;

import com.zsj.amethystfarm.CarpetHooks;
import com.zsj.amethystfarm.data.AmethystFarmDataManager;
import com.zsj.amethystfarm.farm.AmethystFarmProfile;
import com.zsj.amethystfarm.farm.AmethystHarvester;
import com.zsj.amethystfarm.farm.HarvestWhitelist;
import com.zsj.amethystfarm.farm.WorkMode;
import com.zsj.amethystfarm.util.ModCompat;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class AmethystFarmMenu extends class_1703 {
    public static final int SLOT_COUNT = 14;

    public static final int BUTTON_IDLE = 0;
    public static final int BUTTON_SCAN = 1;
    public static final int BUTTON_HARVEST = 2;
    public static final int BUTTON_LOCK = 3;
    public static final int BUTTON_STOP = 4;
    public static final int BUTTON_STATUS = 5;
    public static final int BUTTON_DECOR = 6;
    public static final int BUTTON_DECOR2 = 7;
    public static final int BUTTON_DECOR3 = 8;

    public static final int WHITELIST_SMALL = 9;
    public static final int WHITELIST_MEDIUM = 10;
    public static final int WHITELIST_LARGE = 11;
    public static final int WHITELIST_CLUSTER = 12;
    public static final int WHITELIST_SIDES = 13;

    private final class_1277 buttons = new class_1277(SLOT_COUNT);
    private final UUID fakePlayerId;

    public AmethystFarmMenu(int syncId, class_1661 playerInventory, UUID fakePlayerId) {
        super(AmethystFarmMenuTypes.AMETHYST_FARM_MENU, syncId);
        this.fakePlayerId = fakePlayerId;
        refreshButtons(null);

        for (int i = 0; i < 9; i++) {
            method_7621(new AmethystFarmButtonSlot(buttons, i, 8 + i * 18, 27));
        }
        int whitelistX = 26;
        for (int i = 0; i < 5; i++) {
            method_7621(new AmethystFarmButtonSlot(buttons, WHITELIST_SMALL + i, whitelistX + i * 18, 57));
        }

        addPlayerInventory(playerInventory);
    }

    public void syncFromProfile(class_3222 operator) {
        class_3222 fake = findFakePlayer(ModCompat.serverOf(operator));
        if (fake != null) {
            refreshButtons(AmethystFarmDataManager.get(fake));
            method_37420();
        }
    }

    private void refreshButtons(AmethystFarmProfile profile) {
        HarvestWhitelist whitelist = profile != null ? profile.getHarvestWhitelist() : new HarvestWhitelist();

        buttons.method_5447(BUTTON_IDLE, named(class_1802.field_8871, "空闲模式", WorkMode.IDLE));
        buttons.method_5447(BUTTON_SCAN, named(class_1802.field_27063, "扫描紫水晶", WorkMode.SCAN));
        buttons.method_5447(BUTTON_HARVEST, named(class_1802.field_8403, "挖掘附近紫水晶", WorkMode.HARVEST));
        buttons.method_5447(BUTTON_LOCK, named(class_1802.field_27070, "单点锁定挖掘", WorkMode.LOCK_MINE));
        buttons.method_5447(BUTTON_STOP, named(class_1802.field_8077, "停止", WorkMode.IDLE));
        buttons.method_5447(BUTTON_STATUS, named(class_1802.field_8529, "刷新状态", null));
        buttons.method_5447(BUTTON_DECOR, named(class_1802.field_27064, "紫水晶农场控制", null));
        boolean botEnabled = profile != null && profile.isBotEnabled();
        buttons.method_5447(BUTTON_DECOR2, toggleItem(
            class_1802.field_8530,
            "农场总开关",
            "关闭后不再接管此假人 ActionPack",
            botEnabled
        ));
        buttons.method_5447(BUTTON_DECOR3, named(class_1802.field_8739, "—", null));

        buttons.method_5447(WHITELIST_SMALL, toggleItem(
            class_2246.field_27164.method_8389(),
            "小芽",
            "小型紫水晶芽",
            whitelist.isSmallBud()
        ));
        buttons.method_5447(WHITELIST_MEDIUM, toggleItem(
            class_2246.field_27163.method_8389(),
            "中芽",
            "中型紫水晶芽",
            whitelist.isMediumBud()
        ));
        buttons.method_5447(WHITELIST_LARGE, toggleItem(
            class_2246.field_27162.method_8389(),
            "大芽",
            "大型紫水晶芽",
            whitelist.isLargeBud()
        ));
        buttons.method_5447(WHITELIST_CLUSTER, toggleItem(
            class_2246.field_27161.method_8389(),
            "成熟簇",
            "成熟紫水晶簇",
            whitelist.isCluster()
        ));
        buttons.method_5447(WHITELIST_SIDES, toggleItem(
            class_1802.field_8076,
            "仅母岩侧面",
            "只挖母岩四侧（不含顶/底）",
            whitelist.isSidesOnly()
        ));
    }

    private static class_1799 named(class_1792 item, String name, WorkMode mode) {
        class_1799 stack = new class_1799(item);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470(name));
        if (mode != null) {
            stack.method_57379(class_9334.field_49632, new class_9290(List.of(class_2561.method_43470(mode.getDescription()))));
        }
        return stack;
    }

    private static class_1799 toggleItem(class_1792 enabledItem, String name, String hint, boolean enabled) {
        class_1799 stack = new class_1799(enabled ? enabledItem : class_1802.field_8871);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470(name + (enabled ? " §a[开]" : " §7[关]")));
        stack.method_57379(class_9334.field_49632, new class_9290(List.of(
            class_2561.method_43470(hint),
            class_2561.method_43470("点击切换")
        )));
        return stack;
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 94 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            method_7621(new class_1735(playerInventory, col, 8 + col * 18, 148));
        }
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    @Override
    public boolean method_7604(class_1657 player, int buttonId) {
        if (buttonId >= 0 && buttonId < SLOT_COUNT
            && !player.method_37908().method_8608()
            && player instanceof class_3222 serverPlayer) {
            handleButton(serverPlayer, buttonId);
            return true;
        }
        return false;
    }

    @Override
    public void method_7593(int slotId, int dragType, class_1713 clickType, class_1657 player) {
        if (slotId >= 0 && slotId < SLOT_COUNT
            && !player.method_37908().method_8608()
            && player instanceof class_3222 serverPlayer) {
            handleButton(serverPlayer, slotId);
            return;
        }
        super.method_7593(slotId, dragType, clickType, player);
    }

    private void handleButton(class_3222 operator, int buttonId) {
        class_3222 fake = findFakePlayer(ModCompat.serverOf(operator));
        if (fake == null) {
            operator.method_43496(class_2561.method_43470("找不到绑定的假人"));
            return;
        }
        if (!CarpetHooks.isFakePlayer(fake)) {
            operator.method_43496(class_2561.method_43470("目标必须是 Carpet 假人"));
            return;
        }

        AmethystFarmProfile profile = AmethystFarmDataManager.get(fake);
        HarvestWhitelist whitelist = profile.getHarvestWhitelist();

        switch (buttonId) {
            case BUTTON_IDLE -> AmethystHarvester.applyWorkMode(fake, profile, WorkMode.IDLE);
            case BUTTON_SCAN -> AmethystHarvester.applyWorkMode(fake, profile, WorkMode.SCAN);
            case BUTTON_HARVEST -> AmethystHarvester.applyWorkMode(fake, profile, WorkMode.HARVEST);
            case BUTTON_LOCK -> AmethystHarvester.applyWorkMode(fake, profile, WorkMode.LOCK_MINE);
            case BUTTON_STOP -> AmethystHarvester.disableBot(fake, profile);
            case BUTTON_DECOR2 -> {
                if (profile.isBotEnabled()) {
                    AmethystHarvester.disableBot(fake, profile);
                } else {
                    AmethystHarvester.enableBot(profile);
                }
            }
            case BUTTON_STATUS -> sendStatus(operator, fake, profile);
            case WHITELIST_SMALL -> whitelist.toggleSmallBud();
            case WHITELIST_MEDIUM -> whitelist.toggleMediumBud();
            case WHITELIST_LARGE -> whitelist.toggleLargeBud();
            case WHITELIST_CLUSTER -> whitelist.toggleCluster();
            case WHITELIST_SIDES -> whitelist.toggleSidesOnly();
        }

        refreshButtons(profile);
        method_37420();

        if (buttonId != BUTTON_STATUS && buttonId != BUTTON_DECOR && buttonId != BUTTON_DECOR3) {
            AmethystFarmDataManager.persistProfiles(ModCompat.serverOf(operator));
        }

        if (buttonId == BUTTON_DECOR2 || buttonId == BUTTON_STOP) {
            operator.method_43496(class_2561.method_43470(
                "假人农场: " + (profile.isBotEnabled() ? "已启用" : "已关闭（不影响其他 Carpet 动作）")
            ));
        } else if (buttonId <= BUTTON_LOCK) {
            operator.method_43496(class_2561.method_43470(
                "假人模式: " + profile.getWorkMode().getDisplayName()
                    + (profile.isBotEnabled() ? "" : "（农场未启用）")
            ));
        } else if (buttonId >= WHITELIST_SMALL && buttonId <= WHITELIST_SIDES) {
            operator.method_43496(class_2561.method_43470("挖掘白名单: " + whitelist.formatSummary().getString()));
        }
    }

    private void sendStatus(class_3222 operator, class_3222 fake, AmethystFarmProfile profile) {
        operator.method_43496(class_2561.method_43470(
            "假人 " + fake.method_5477().getString()
                + " | 农场: " + (profile.isBotEnabled() ? "已启用" : "未启用")
                + " | 模式: " + profile.getWorkMode().getDisplayName()
                + " | 白名单: " + profile.getHarvestWhitelist().formatSummary().getString()
                + " | 附近可挖: " + profile.getCrystalCount()
                + " | 手长内: " + profile.getReachableCrystalCount()
                + " | 成熟簇: " + profile.getClusterCount()
        ));
    }

    private class_3222 findFakePlayer(net.minecraft.server.MinecraftServer server) {
        return server.method_3760().method_14602(fakePlayerId);
    }
}
