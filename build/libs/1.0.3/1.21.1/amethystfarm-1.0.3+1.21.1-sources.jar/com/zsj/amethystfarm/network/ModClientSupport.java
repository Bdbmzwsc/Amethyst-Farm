package com.zsj.amethystfarm.network;

import com.zsj.amethystfarm.AmethystFarmMod;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;

/** Detects whether a player has the Amethyst Farm client mod installed. */
public final class ModClientSupport {
    private ModClientSupport() {}

    public static boolean hasClientMod(class_3222 player) {
        return ServerPlayNetworking.canSend(player, SettingsSyncPayload.TYPE);
    }

    public static void requireClientModOrNotify(class_3222 player) {
        player.method_43496(net.minecraft.class_2561.method_43470(
            "此功能需要客户端安装 " + AmethystFarmMod.MOD_ID + " 模组（GUI / 预览）。"
                + "无模组玩家仍可使用 /af 命令控制假人。"
        ));
    }
}
