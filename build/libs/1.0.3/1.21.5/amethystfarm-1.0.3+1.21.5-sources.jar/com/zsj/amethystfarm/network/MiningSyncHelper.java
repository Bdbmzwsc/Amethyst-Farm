package com.zsj.amethystfarm.network;

import com.zsj.amethystfarm.config.AmethystFarmSettings;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class MiningSyncHelper {
    private static final ConcurrentHashMap<Integer, class_2338> LAST_TARGETS = new ConcurrentHashMap<>();

    private MiningSyncHelper() {}

    public static void broadcastTarget(class_3222 fake, class_2338 target) {
        if (!(fake.method_37908() instanceof class_3218 level)) {
            return;
        }

        class_2338 previous = LAST_TARGETS.get(fake.method_5628());
        if (target.equals(previous)) {
            return;
        }
        LAST_TARGETS.put(fake.method_5628(), target.method_10062());

        NetworkBroadcast.sendToWorldNear(
            level,
            target,
            AmethystFarmSettings.maxRenderDistance + 8,
            MiningTargetPayload.of(fake.method_5628(), target),
            MiningTargetPayload.TYPE
        );
    }

    public static void broadcastClear(class_3222 fake) {
        if (!(fake.method_37908() instanceof class_3218 level)) {
            return;
        }

        if (LAST_TARGETS.remove(fake.method_5628()) == null) {
            return;
        }

        NetworkBroadcast.sendToWorld(level, MiningTargetPayload.cleared(fake.method_5628()), MiningTargetPayload.TYPE);
    }
}
