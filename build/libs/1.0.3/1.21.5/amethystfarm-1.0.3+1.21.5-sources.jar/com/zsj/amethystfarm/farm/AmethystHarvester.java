package com.zsj.amethystfarm.farm;

import carpet.fakes.ServerPlayerInterface;
import carpet.helpers.EntityPlayerActionPack;
import com.zsj.amethystfarm.config.AmethystFarmSettings;
import com.zsj.amethystfarm.fakes.AmethystFarmBotAccess;
import com.zsj.amethystfarm.network.MiningSyncHelper;
import com.zsj.amethystfarm.network.PreviewSyncHelper;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class AmethystHarvester {
    private AmethystHarvester() {}

    public static void enableBot(AmethystFarmProfile profile) {
        profile.setBotEnabled(true);
    }

    /** Disables per-bot control and releases any in-progress farm actions once. */
    public static void disableBot(class_3222 fake, AmethystFarmProfile profile) {
        profile.setBotEnabled(false);
        profile.setWorkMode(WorkMode.IDLE);
        profile.setLockedTarget(null);
        if (!(fake.method_37908() instanceof class_3218 level)) {
            return;
        }
        if (profile.clearScanPreviewIfNeeded()) {
            PreviewSyncHelper.broadcastClear(fake);
        }
        releaseMining(fake, level, profile, true);
    }

    public static void applyWorkMode(class_3222 fake, AmethystFarmProfile profile, WorkMode mode) {
        WorkMode previous = profile.getWorkMode();
        if (mode != WorkMode.IDLE) {
            profile.setBotEnabled(true);
        }
        profile.setWorkMode(mode);
        if (!(fake.method_37908() instanceof class_3218 level)) {
            return;
        }
        if (isMiningMode(previous) && !isMiningMode(mode)) {
            releaseMining(fake, level, profile, true);
        }
        if (previous == WorkMode.SCAN && mode != WorkMode.SCAN && profile.clearScanPreviewIfNeeded()) {
            PreviewSyncHelper.broadcastClear(fake);
        }
    }

    public static void tickFakePlayer(class_3222 fake, AmethystFarmProfile profile) {
        if (!AmethystFarmSettings.enabled || !profile.isBotEnabled()) {
            return;
        }

        if (!(fake.method_37908() instanceof class_3218 level)) {
            return;
        }

        if (!isMiningMode(profile.getWorkMode()) && hasActiveMiningState(profile)) {
            releaseMining(fake, level, profile, true);
        }

        profile.ensureTickPhase(fake.method_5667(), AmethystFarmSettings.scanInterval);

        if (profile.getWorkMode() != WorkMode.SCAN && profile.clearScanPreviewIfNeeded()) {
            PreviewSyncHelper.broadcastClear(fake);
        }

        profile.setTickCounter(profile.getTickCounter() + 1);
        if (profile.getTickCounter() < AmethystFarmSettings.scanInterval) {
            if (isMiningMode(profile.getWorkMode())) {
                continueMiningTarget(fake, level, profile);
            }
            return;
        }
        profile.setTickCounter(0);

        if (nearbyScanVolume() > AmethystFarmSettings.maxScanVolume) {
            return;
        }

        switch (profile.getWorkMode()) {
            case SCAN -> handleScan(fake, level, profile);
            case HARVEST -> handleHarvest(fake, level, profile);
            case LOCK_MINE -> handleLockMine(fake, level, profile);
            case IDLE -> {
            }
        }
    }

    private static boolean isMiningMode(WorkMode mode) {
        return mode == WorkMode.HARVEST || mode == WorkMode.LOCK_MINE;
    }

    private static boolean hasActiveMiningState(AmethystFarmProfile profile) {
        return profile.getMiningTarget() != null
            || profile.getBreakingBlockPos() != null
            || profile.isMiningAttackActive();
    }

    private static int nearbyScanVolume() {
        int radius = AmethystFarmSettings.scanRadius;
        int edge = radius * 2 + 1;
        return edge * edge * edge;
    }

    private static int scanRadiusFor(class_3222 fake) {
        return AmethystFarmSettings.scanRadius;
    }

    private static boolean isValidMiningTarget(
        class_3222 fake,
        class_3218 level,
        AmethystFarmProfile profile,
        class_2338 target
    ) {
        class_2680 state = level.method_8320(target);
        if (!AmethystCrystalHelper.matchesHarvestWhitelist(state, level, target, profile.getHarvestWhitelist())) {
            return false;
        }
        if (!AmethystReachHelper.isWithinReach(fake, target)) {
            return false;
        }
        return MiningClaimRegistry.isAvailable(level.method_27983(), fake.method_5667(), target);
    }

    private static void releaseMining(
        class_3222 fake,
        class_3218 level,
        AmethystFarmProfile profile,
        boolean stopActionPack
    ) {
        boolean hadActivity = hasActiveMiningState(profile);
        if (profile.clearMiningTargetIfNeeded()) {
            MiningSyncHelper.broadcastClear(fake);
        }
        profile.clearMiningAttack();
        AmethystBlockBreaker.abort(fake, level, profile);
        MiningClaimRegistry.release(fake);
        if (stopActionPack && hadActivity) {
            actionPack(fake).stopAll();
        }
    }

    private static void continueMiningTarget(class_3222 fake, class_3218 level, AmethystFarmProfile profile) {
        class_2338 target = profile.getMiningTarget();
        if (target == null) {
            if (profile.getWorkMode() == WorkMode.HARVEST && AmethystFarmSettings.autoHarvest) {
                tryAssignHarvestTarget(fake, level, profile);
            }
            return;
        }
        if (!isValidMiningTarget(fake, level, profile, target)) {
            releaseMining(fake, level, profile, true);
            return;
        }
        maintainMining(fake, level, profile, target);
    }

    private static void handleScan(class_3222 fake, class_3218 level, AmethystFarmProfile profile) {
        int radius = scanRadiusFor(fake);
        HarvestWhitelist whitelist = profile.getHarvestWhitelist();
        AmethystFarmBinding bounds = AmethystScanner.nearbyBounds(fake, radius);
        AmethystScanner.ScanResult result = AmethystScanner.scanNearby(level, fake, whitelist, radius);
        updateScanStats(profile, result, level, fake);
        AmethystScanner.spawnPreviewParticles(level, bounds, result);
        ((AmethystFarmBotAccess) fake).amethystfarm$setPreviewBinding(bounds, result);
        profile.markScanPreviewActive();
        PreviewSyncHelper.broadcastScan(fake, bounds, result);
    }

    private static void handleHarvest(class_3222 fake, class_3218 level, AmethystFarmProfile profile) {
        if (!AmethystFarmSettings.autoHarvest) {
            return;
        }

        class_2338 currentTarget = profile.getMiningTarget();
        if (currentTarget != null && isValidMiningTarget(fake, level, profile, currentTarget)) {
            mineCrystal(fake, level, profile, currentTarget);
            return;
        }

        tryAssignHarvestTarget(fake, level, profile);
    }

    private static void tryAssignHarvestTarget(class_3222 fake, class_3218 level, AmethystFarmProfile profile) {
        AmethystScanner.ScanResult result = AmethystScanner.scanNearby(
            level, fake, profile.getHarvestWhitelist(), scanRadiusFor(fake)
        );
        updateScanStats(profile, result, level, fake);

        List<class_2338> candidates = rankedHarvestCandidates(fake, level, result.harvestableCrystals());
        if (candidates.isEmpty()) {
            releaseMining(fake, level, profile, hasActiveMiningState(profile));
            return;
        }

        for (class_2338 target : candidates) {
            if (beginMiningCrystal(fake, level, profile, target)) {
                maintainMining(fake, level, profile, target);
                return;
            }
        }

        releaseMining(fake, level, profile, hasActiveMiningState(profile));
    }

    private static List<class_2338> rankedHarvestCandidates(
        class_3222 fake,
        class_3218 level,
        List<class_2338> crystals
    ) {
        List<class_2338> inReach = AmethystReachHelper.filterInReach(fake, crystals);
        List<class_2338> available = MiningClaimRegistry.filterAvailable(fake, inReach);
        Comparator<class_2338> order = AmethystCrystalHelper.harvestPriorityComparator(level)
            .thenComparingDouble(pos -> fake.method_5707(AmethystBlockBreaker.lookPoint(level.method_8320(pos), pos)));
        List<class_2338> ranked = new ArrayList<>(available);
        ranked.sort(order);
        return ranked;
    }

    private static void handleLockMine(class_3222 fake, class_3218 level, AmethystFarmProfile profile) {
        class_2338 target = profile.getLockedTarget();

        if (target == null || !isValidMiningTarget(fake, level, profile, target)) {
            HarvestWhitelist whitelist = profile.getHarvestWhitelist();
            target = AmethystScanner.findCrystalInLookDirection(fake, whitelist);
            if (target == null) {
                List<class_2338> candidates = rankedHarvestCandidates(
                    fake,
                    level,
                    AmethystScanner.scanNearby(level, fake, whitelist, scanRadiusFor(fake)).harvestableCrystals()
                );
                target = candidates.isEmpty() ? null : candidates.getFirst();
            }
            profile.setLockedTarget(target);
        }

        if (target == null) {
            releaseMining(fake, level, profile, hasActiveMiningState(profile));
            return;
        }

        mineCrystal(fake, level, profile, target);

        if (!AmethystCrystalHelper.matchesHarvestWhitelist(
            level.method_8320(target), level, target, profile.getHarvestWhitelist())) {
            profile.setLockedTarget(null);
            releaseMining(fake, level, profile, true);
        }
    }

    private static void updateScanStats(
        AmethystFarmProfile profile,
        AmethystScanner.ScanResult result,
        class_3218 level,
        class_3222 fake
    ) {
        profile.setBuddingCount(result.buddingBlocks().size());
        profile.setCrystalCount(result.harvestableCrystals().size());
        profile.setClusterCount(result.matureClusterCount(level));
        profile.setReachableCrystalCount(result.inReachCount(fake));
    }

    private static void mineCrystal(class_3222 fake, class_3218 level, AmethystFarmProfile profile, class_2338 target) {
        if (!beginMiningCrystal(fake, level, profile, target)) {
            return;
        }
        maintainMining(fake, level, profile, target);
    }

    private static boolean beginMiningCrystal(
        class_3222 fake,
        class_3218 level,
        AmethystFarmProfile profile,
        class_2338 target
    ) {
        if (!isValidMiningTarget(fake, level, profile, target)) {
            return false;
        }

        class_2338 previousTarget = profile.getMiningTarget();
        boolean sameTarget = target.equals(previousTarget);

        if (!sameTarget) {
            if (!MiningClaimRegistry.tryClaim(fake, target)) {
                return false;
            }
            class_2338 breaking = profile.getBreakingBlockPos();
            if (breaking != null && !breaking.equals(target)) {
                AmethystBlockBreaker.abort(fake, level, profile);
            }
            profile.setMiningTarget(target);
            MiningSyncHelper.broadcastTarget(fake, target);
            profile.clearMiningAttack();
        }

        return true;
    }

    private static void maintainMining(
        class_3222 fake,
        class_3218 level,
        AmethystFarmProfile profile,
        class_2338 target
    ) {
        if (!isValidMiningTarget(fake, level, profile, target)) {
            releaseMining(fake, level, profile, true);
            return;
        }

        AmethystBlockBreaker.tickBreak(fake, level, profile, target, profile.getHarvestWhitelist());

        if (!AmethystCrystalHelper.matchesHarvestWhitelist(
            level.method_8320(target), level, target, profile.getHarvestWhitelist())) {
            releaseMining(fake, level, profile, true);
        }
    }

    private static EntityPlayerActionPack actionPack(class_3222 fake) {
        return ((ServerPlayerInterface) fake).getActionPack();
    }
}
