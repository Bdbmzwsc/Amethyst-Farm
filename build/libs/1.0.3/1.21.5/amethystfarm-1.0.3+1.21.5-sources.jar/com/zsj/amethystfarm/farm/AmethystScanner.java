package com.zsj.amethystfarm.farm;

import com.zsj.amethystfarm.config.AmethystFarmSettings;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class AmethystScanner {
    private AmethystScanner() {}

    public record ScanResult(List<class_2338> buddingBlocks, List<class_2338> harvestableCrystals) {
        public int matureClusterCount(class_3218 level) {
            return (int) harvestableCrystals.stream()
                .filter(pos -> AmethystCrystalHelper.isMatureCluster(level.method_8320(pos)))
                .count();
        }

        public int inReachCount(class_3222 player) {
            return AmethystReachHelper.filterInReach(player, harvestableCrystals).size();
        }
    }

    public static ScanResult scan(class_3218 level, AmethystFarmBinding binding, HarvestWhitelist whitelist) {
        List<class_2338> budding = new ArrayList<>();
        List<class_2338> crystals = new ArrayList<>();

        if (!binding.isBound()) {
            return new ScanResult(budding, crystals);
        }

        class_2338 min = binding.getMin();
        class_2338 max = binding.getMax();

        for (int x = min.method_10263(); x <= max.method_10263(); x++) {
            for (int y = min.method_10264(); y <= max.method_10264(); y++) {
                for (int z = min.method_10260(); z <= max.method_10260(); z++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = level.method_8320(pos);
                    if (state.method_27852(class_2246.field_27160)) {
                        budding.add(pos.method_10062());
                    } else if (AmethystCrystalHelper.matchesHarvestWhitelist(state, level, pos, whitelist)) {
                        crystals.add(pos.method_10062());
                    }
                }
            }
        }

        return new ScanResult(budding, crystals);
    }

    public static ScanResult scan(class_3218 level, AmethystFarmBinding binding) {
        HarvestWhitelist all = new HarvestWhitelist();
        all.setSidesOnly(false);
        return scan(level, binding, all);
    }

    public static ScanResult scanNearby(
        class_3218 level,
        class_3222 player,
        HarvestWhitelist whitelist,
        int radius
    ) {
        return scan(level, AmethystFarmBinding.around(player.method_24515(), radius, level.method_27983()), whitelist);
    }

    public static AmethystFarmBinding nearbyBounds(class_3222 player, int radius) {
        return AmethystFarmBinding.around(player.method_24515(), radius, player.method_37908().method_27983());
    }

    public static class_2338 findNearestCrystal(class_3222 player, HarvestWhitelist whitelist, int radius) {
        if (!(player.method_37908() instanceof class_3218 level)) {
            return null;
        }
        ScanResult result = scanNearby(level, player, whitelist, radius);
        return selectHarvestTarget(player, level, result.harvestableCrystals());
    }

    public static class_2338 findCrystalInLookDirection(class_3222 player, HarvestWhitelist whitelist) {
        if (!(player.method_37908() instanceof class_3218 level)) {
            return null;
        }

        double reach = AmethystReachHelper.getMiningReach(player);
        class_243 eye = player.method_33571();
        class_243 look = player.method_5720();

        class_2338.class_2339 mutable = new class_2338.class_2339();
        for (double d = 0; d <= reach; d += 0.25) {
            class_243 sample = eye.method_1019(look.method_1021(d));
            mutable.method_10102(sample.field_1352, sample.field_1351, sample.field_1350);
            class_2680 state = level.method_8320(mutable);
            if (AmethystCrystalHelper.matchesHarvestWhitelist(state, level, mutable, whitelist)
                && MiningClaimRegistry.isAvailable(level.method_27983(), player.method_5667(), mutable)) {
                return mutable.method_10062();
            }
        }

        return null;
    }

    public static class_2338 selectHarvestTarget(class_3222 player, class_3218 level, List<class_2338> crystals) {
        List<class_2338> inReach = AmethystReachHelper.filterInReach(player, crystals);
        List<class_2338> available = MiningClaimRegistry.filterAvailable(player, inReach);
        return available.stream()
            .min(AmethystCrystalHelper.harvestPriorityComparator(level)
                .thenComparingDouble(pos -> player.method_5707(class_243.method_24953(pos))))
            .orElse(null);
    }

    public static void spawnPreviewParticles(class_3218 level, AmethystFarmBinding binding, ScanResult result) {
        if (!AmethystFarmSettings.scanPreview) {
            return;
        }

        class_2338 min = binding.getMin();
        class_2338 max = binding.getMax();
        spawnCornerParticles(level, min);
        spawnCornerParticles(level, max);
        spawnCornerParticles(level, new class_2338(min.method_10263(), min.method_10264(), max.method_10260()));
        spawnCornerParticles(level, new class_2338(min.method_10263(), max.method_10264(), min.method_10260()));
        spawnCornerParticles(level, new class_2338(max.method_10263(), min.method_10264(), min.method_10260()));
        spawnCornerParticles(level, new class_2338(max.method_10263(), max.method_10264(), min.method_10260()));
        spawnCornerParticles(level, new class_2338(min.method_10263(), max.method_10264(), max.method_10260()));
        spawnCornerParticles(level, new class_2338(max.method_10263(), min.method_10264(), max.method_10260()));

        for (class_2338 pos : result.buddingBlocks()) {
            level.method_65096(
                class_2398.field_11207,
                pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                1, 0.05, 0.05, 0.05, 0.0
            );
        }

        for (class_2338 pos : result.harvestableCrystals()) {
            class_2680 state = level.method_8320(pos);
            if (AmethystCrystalHelper.isMatureCluster(state)) {
                level.method_65096(
                    class_2398.field_29642,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                    3, 0.1, 0.1, 0.1, 0.01
                );
            } else {
                level.method_65096(
                    class_2398.field_11249,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                    2, 0.08, 0.08, 0.08, 0.01
                );
            }
        }
    }

    private static void spawnCornerParticles(class_3218 level, class_2338 pos) {
        level.method_65096(
            class_2398.field_28479,
            pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
            2, 0.0, 0.0, 0.0, 0.0
        );
    }
}
