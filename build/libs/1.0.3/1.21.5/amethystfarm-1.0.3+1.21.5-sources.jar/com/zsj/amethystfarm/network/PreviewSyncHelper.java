package com.zsj.amethystfarm.network;

import com.zsj.amethystfarm.config.AmethystFarmSettings;
import com.zsj.amethystfarm.farm.AmethystFarmBinding;
import com.zsj.amethystfarm.farm.AmethystScanner;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class PreviewSyncHelper {
    private PreviewSyncHelper() {}

    public static void broadcastScan(class_3222 fake, AmethystFarmBinding binding, AmethystScanner.ScanResult result) {
        if (!(fake.method_37908() instanceof class_3218 level) || !AmethystFarmSettings.scanPreview) {
            return;
        }

        List<class_2338> crystals = trimCrystals(result.harvestableCrystals(), fake.method_19538(), AmethystFarmSettings.previewCrystalLimit);
        PreviewSyncStateTracker.buildUpdate(fake.method_5628(), binding, crystals, level).ifPresent(payload ->
            NetworkBroadcast.sendToWorldNear(
                level,
                binding.getMin(),
                AmethystFarmSettings.maxRenderDistance + 16,
                payload,
                PreviewSyncPayload.TYPE
            )
        );
    }

    public static void broadcastClear(class_3222 fake) {
        if (!(fake.method_37908() instanceof class_3218 level)) {
            return;
        }
        PreviewSyncStateTracker.clear(fake.method_5628());
        NetworkBroadcast.sendToWorld(level, PreviewSyncPayload.cleared(fake.method_5628()), PreviewSyncPayload.TYPE);
    }

    private static List<class_2338> trimCrystals(List<class_2338> crystals, class_243 origin, int limit) {
        if (crystals.size() <= limit) {
            return crystals;
        }

        List<class_2338> sorted = new ArrayList<>(crystals);
        sorted.sort(Comparator.comparingDouble(pos -> pos.method_46558().method_1025(origin)));
        return List.copyOf(sorted.subList(0, limit));
    }
}
