package com.zsj.amethystfarm.gui;

import com.zsj.amethystfarm.AmethystFarmMod;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import com.zsj.amethystfarm.network.ModClientSupport;

public final class AmethystFarmMenus {
    private AmethystFarmMenus() {}

    public static void register() {
        AmethystFarmMenuTypes.AMETHYST_FARM_MENU = net.minecraft.class_2378.method_10230(
            class_7923.field_41187,
            class_2960.method_60655(AmethystFarmMod.MOD_ID, "amethyst_farm"),
            new ExtendedScreenHandlerType<>(
                (syncId, inv, data) -> new AmethystFarmMenu(syncId, inv, data.fakePlayerId()),
                AmethystFarmMenuData.STREAM_CODEC
            )
        );
    }

    public static void open(class_3222 operator, class_3222 fakePlayer) {
        if (!ModClientSupport.hasClientMod(operator)) {
            ModClientSupport.requireClientModOrNotify(operator);
            return;
        }
        operator.method_17355(new ExtendedScreenHandlerFactory<AmethystFarmMenuData>() {
            @Override
            public AmethystFarmMenuData getScreenOpeningData(class_3222 player) {
                return new AmethystFarmMenuData(fakePlayer.method_5667());
            }

            @Override
            public class_2561 method_5476() {
                return class_2561.method_43470("紫水晶农场 — " + fakePlayer.method_5477().getString());
            }

            @Override
            public class_1703 createMenu(int syncId, class_1661 inv, class_1657 player) {
                return new AmethystFarmMenu(syncId, inv, fakePlayer.method_5667());
            }
        });
        if (operator.field_7512 instanceof AmethystFarmMenu menu) {
            menu.syncFromProfile(operator);
        }
    }
}
