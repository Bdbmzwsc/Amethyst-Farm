package com.zsj.amethystfarm.client;

import com.zsj.amethystfarm.client.preview.ClientMiningCache;
import com.zsj.amethystfarm.client.preview.ClientPreviewCache;
import com.zsj.amethystfarm.client.render.CachedCrystalOutline;
import com.zsj.amethystfarm.client.render.ClientRenderConfig;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_12249;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class AmethystPreviewRenderer {
    private AmethystPreviewRenderer() {}

    public static void register() {
        WorldRenderEvents.END_MAIN.register(AmethystPreviewRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        if (ClientPreviewCache.isEmpty() && ClientMiningCache.isEmpty()) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) {
            return;
        }

        var consumers = context.consumers();
        if (consumers == null) {
            return;
        }

        class_243 camera = context.worldState().field_63082.field_63078;
        double maxDistSqr = ClientRenderConfig.maxRenderDistanceSqr();
        class_4587 matrices = context.matrices();
        class_4588 lines = consumers.method_73477(class_12249.method_76015());

        matrices.method_22903();
        matrices.method_22904(-camera.field_1352, -camera.field_1351, -camera.field_1350);

        for (var entry : ClientPreviewCache.all().entrySet()) {
            ClientPreviewCache.CrystalPreview preview = entry.getValue();

            if (ClientRenderConfig.drawRegionBox) {
                renderRegionBox(matrices, lines, preview, camera, maxDistSqr);
            }

            for (CachedCrystalOutline outline : selectVisible(preview.crystalList(), camera, maxDistSqr,
                ClientRenderConfig.maxCrystalOutlines)) {
                drawOutline(matrices, lines, outline, outline.mature() ? 0.25f : 0.75f,
                    outline.mature() ? 1.0f : 0.45f, outline.mature() ? 0.45f : 1.0f);
            }
        }

        for (CachedCrystalOutline outline : ClientMiningCache.all().values()) {
            if (outline.distanceSquaredTo(camera) > maxDistSqr) {
                continue;
            }
            drawOutline(matrices, lines, outline, 1.0f, 0.15f, 0.15f);
        }

        matrices.method_22909();
    }

    private static void renderRegionBox(
        class_4587 matrices,
        class_4588 lines,
        ClientPreviewCache.CrystalPreview preview,
        class_243 camera,
        double maxDistSqr
    ) {
        class_2338 min = new class_2338(
            Math.min(preview.pos1().method_10263(), preview.pos2().method_10263()),
            Math.min(preview.pos1().method_10264(), preview.pos2().method_10264()),
            Math.min(preview.pos1().method_10260(), preview.pos2().method_10260())
        );
        class_2338 max = new class_2338(
            Math.max(preview.pos1().method_10263(), preview.pos2().method_10263()),
            Math.max(preview.pos1().method_10264(), preview.pos2().method_10264()),
            Math.max(preview.pos1().method_10260(), preview.pos2().method_10260())
        );

        class_238 world = new class_238(min.method_10263(), min.method_10264(), min.method_10260(), max.method_10263() + 1, max.method_10264() + 1, max.method_10260() + 1);
        if (world.method_1005().method_1025(camera) > maxDistSqr * 4) {
            return;
        }

        net.minecraft.class_9974.method_62296(
            matrices, lines, class_259.method_1078(world), 0, 0, 0, packColor(0.6f, 0.2f, 1.0f, 0.6f), 1.0f
        );
    }

    private static List<CachedCrystalOutline> selectVisible(
        List<CachedCrystalOutline> crystals,
        class_243 camera,
        double maxDistSqr,
        int limit
    ) {
        if (crystals.isEmpty()) {
            return List.of();
        }

        List<CachedCrystalOutline> inRange = new ArrayList<>(Math.min(limit, crystals.size()));
        for (CachedCrystalOutline outline : crystals) {
            if (outline.distanceSquaredTo(camera) <= maxDistSqr) {
                inRange.add(outline);
            }
        }

        if (inRange.size() <= limit) {
            return inRange;
        }

        inRange.sort(Comparator
            .comparingDouble((CachedCrystalOutline o) -> o.distanceSquaredTo(camera))
            .thenComparingInt(o -> o.pos().method_10263())
            .thenComparingInt(o -> o.pos().method_10264())
            .thenComparingInt(o -> o.pos().method_10260()));
        return List.copyOf(inRange.subList(0, limit));
    }

    private static void drawOutline(
        class_4587 matrices,
        class_4588 lines,
        CachedCrystalOutline outline,
        float r,
        float g,
        float b
    ) {
        class_238 box = outline.localBounds().method_996(outline.pos()).method_1014(0.01);
        net.minecraft.class_9974.method_62296(
            matrices, lines, class_259.method_1078(box), 0, 0, 0, packColor(r, g, b, 0.9f), 1.0f
        );
    }

    private static int packColor(float r, float g, float b, float a) {
        return ((int) (a * 255.0F) << 24)
            | ((int) (r * 255.0F) << 16)
            | ((int) (g * 255.0F) << 8)
            | (int) (b * 255.0F);
    }
}
