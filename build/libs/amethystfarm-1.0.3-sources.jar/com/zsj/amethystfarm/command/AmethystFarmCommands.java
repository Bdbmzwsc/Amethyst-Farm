package com.zsj.amethystfarm.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.zsj.amethystfarm.AmethystFarmRuntime;
import com.zsj.amethystfarm.CarpetHooks;
import com.zsj.amethystfarm.config.AmethystFarmSettings;
import com.zsj.amethystfarm.data.AmethystFarmDataManager;
import com.zsj.amethystfarm.farm.AmethystFarmProfile;
import com.zsj.amethystfarm.farm.AmethystHarvester;
import com.zsj.amethystfarm.farm.WorkMode;
import com.zsj.amethystfarm.gui.AmethystFarmMenus;
import com.zsj.amethystfarm.network.ModClientSupport;
import com.zsj.amethystfarm.network.SettingsSyncHelper;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Collection;
import java.util.List;

public final class AmethystFarmCommands {
    public static final String PRIMARY_ROOT = "amethystfarm";
    public static final String SHORT_ROOT = "af";

    private static final SuggestionProvider<class_2168> RULE_SUGGESTIONS = (ctx, builder) ->
        class_2172.method_9265(AmethystFarmSettings.ruleNames(), builder);

    private static final SuggestionProvider<class_2168> MODE_SUGGESTIONS = (ctx, builder) ->
        class_2172.method_9265(List.of("IDLE", "SCAN", "HARVEST", "LOCK_MINE"), builder);

    private static final SuggestionProvider<class_2168> FAKE_PLAYER_SUGGESTIONS = (ctx, builder) -> {
        MinecraftServer server = ctx.getSource().method_9211();
        if (server != null) {
            for (class_3222 player : CarpetHooks.getOnlineFakePlayers(server)) {
                builder.suggest(player.method_7334().name());
            }
        }
        return builder.buildFuture();
    };

    private AmethystFarmCommands() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(buildRoot(PRIMARY_ROOT));
        dispatcher.register(buildRoot(SHORT_ROOT));
    }

    private static LiteralArgumentBuilder<class_2168> buildRoot(String root) {
        return class_2170.method_9247(root)
            .then(class_2170.method_9247("list")
                .executes(AmethystFarmCommands::listFakes))
            .then(class_2170.method_9247("gui")
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .suggests(FAKE_PLAYER_SUGGESTIONS)
                    .executes(ctx -> openGui(ctx, class_2186.method_9315(ctx, "player")))))
            .then(class_2170.method_9247("harvest")
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .suggests(FAKE_PLAYER_SUGGESTIONS)
                    .executes(ctx -> startHarvest(ctx, class_2186.method_9315(ctx, "player")))))
            .then(class_2170.method_9247("stop")
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .suggests(FAKE_PLAYER_SUGGESTIONS)
                    .executes(ctx -> stopFake(ctx, class_2186.method_9315(ctx, "player")))))
            .then(class_2170.method_9247("on")
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .suggests(FAKE_PLAYER_SUGGESTIONS)
                    .executes(ctx -> enableBot(ctx, class_2186.method_9315(ctx, "player")))))
            .then(class_2170.method_9247("off")
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .suggests(FAKE_PLAYER_SUGGESTIONS)
                    .executes(ctx -> disableBot(ctx, class_2186.method_9315(ctx, "player")))))
            .then(class_2170.method_9247("mode")
                .then(class_2170.method_9244("mode", StringArgumentType.word())
                    .suggests(MODE_SUGGESTIONS)
                    .then(class_2170.method_9244("player", class_2186.method_9305())
                        .suggests(FAKE_PLAYER_SUGGESTIONS)
                        .executes(ctx -> setMode(
                            ctx,
                            class_2186.method_9315(ctx, "player"),
                            StringArgumentType.getString(ctx, "mode")
                        )))))
            .then(class_2170.method_9247("status")
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .suggests(FAKE_PLAYER_SUGGESTIONS)
                    .executes(ctx -> showStatus(ctx, class_2186.method_9315(ctx, "player")))))
            .then(buildBatchNode())
            .then(class_2170.method_9247("rule")
                .then(class_2170.method_9247("list")
                    .executes(AmethystFarmCommands::listRules))
                .then(class_2170.method_9247("get")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(RULE_SUGGESTIONS)
                        .executes(ctx -> getRule(ctx, StringArgumentType.getString(ctx, "name")))))
                .then(class_2170.method_9247("set")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(RULE_SUGGESTIONS)
                        .then(class_2170.method_9244("value", StringArgumentType.greedyString())
                            .executes(ctx -> setRule(
                                ctx,
                                StringArgumentType.getString(ctx, "name"),
                                StringArgumentType.getString(ctx, "value")
                            ))))));
    }

    private static LiteralArgumentBuilder<class_2168> buildBatchNode() {
        return class_2170.method_9247("batch")
            .then(class_2170.method_9247("mode")
                .then(class_2170.method_9244("mode", StringArgumentType.word())
                    .suggests(MODE_SUGGESTIONS)
                    .then(class_2170.method_9244("targets", class_2186.method_9308())
                        .executes(ctx -> batchSetMode(
                            ctx,
                            StringArgumentType.getString(ctx, "mode"),
                            class_2186.method_9312(ctx, "targets")
                        )))))
            .then(class_2170.method_9247("harvest")
                .then(class_2170.method_9244("targets", class_2186.method_9308())
                    .executes(ctx -> batchHarvest(ctx, class_2186.method_9312(ctx, "targets")))));
    }

    private static void persistProfiles(CommandContext<class_2168> ctx) {
        MinecraftServer server = ctx.getSource().method_9211();
        if (server != null) {
            AmethystFarmDataManager.persistProfiles(server);
        }
    }

    private static int listFakes(CommandContext<class_2168> ctx) {
        if (!requireCarpet(ctx)) {
            return 0;
        }
        MinecraftServer server = ctx.getSource().method_9211();
        List<class_3222> fakes = CarpetHooks.getOnlineFakePlayers(server);
        if (fakes.isEmpty()) {
            ctx.getSource().method_9226(() -> class_2561.method_43470("当前没有在线 Carpet 假人"), false);
            return 0;
        }
        for (class_3222 fake : fakes) {
            boolean active = AmethystFarmDataManager.isFarmActive(fake);
            AmethystFarmProfile profile = active ? AmethystFarmDataManager.get(fake) : null;
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                fake.method_5477().getString()
                    + " | " + (active ? "农场已启用" : "未纳入农场")
                    + (profile != null ? " | " + profile.getWorkMode().name() : "")
                    + (profile != null ? " | 附近可挖: " + profile.getCrystalCount() : "")
                    + (profile != null ? " | 手长内: " + profile.getReachableCrystalCount() : "")
            ), false);
        }
        ctx.getSource().method_9226(() -> class_2561.method_43470("共 " + fakes.size() + " 个假人在线"), false);
        return fakes.size();
    }

    private static int batchSetMode(CommandContext<class_2168> ctx, String modeName, Collection<class_3222> targets)
        throws CommandSyntaxException {
        if (!requireCarpet(ctx)) {
            return 0;
        }
        WorkMode mode;
        try {
            mode = WorkMode.fromString(modeName);
        } catch (IllegalArgumentException e) {
            ctx.getSource().method_9213(class_2561.method_43470("未知模式，可用: IDLE, SCAN, HARVEST, LOCK_MINE"));
            return 0;
        }
        String invalid = findNonFakeName(targets);
        if (invalid != null) {
            ctx.getSource().method_9213(class_2561.method_43470("目标必须是 Carpet 假人: " + invalid));
            return 0;
        }
        for (class_3222 target : targets) {
            AmethystHarvester.applyWorkMode(target, AmethystFarmDataManager.get(target), mode);
        }
        persistProfiles(ctx);
        int count = targets.size();
        WorkMode appliedMode = mode;
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "已将 " + count + " 个假人设为 " + appliedMode.getDisplayName()
        ), true);
        return count;
    }

    private static int batchHarvest(CommandContext<class_2168> ctx, Collection<class_3222> targets)
        throws CommandSyntaxException {
        if (!requireCarpet(ctx)) {
            return 0;
        }
        String invalid = findNonFakeName(targets);
        if (invalid != null) {
            ctx.getSource().method_9213(class_2561.method_43470("目标必须是 Carpet 假人: " + invalid));
            return 0;
        }
        for (class_3222 target : targets) {
            AmethystHarvester.applyWorkMode(target, AmethystFarmDataManager.get(target), WorkMode.HARVEST);
        }
        persistProfiles(ctx);
        int count = targets.size();
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "已启用并令 " + count + " 个假人开始挖掘附近紫水晶"
        ), true);
        return count;
    }

    private static String findNonFakeName(Collection<class_3222> players) {
        for (class_3222 player : players) {
            if (!CarpetHooks.isFakePlayer(player)) {
                return player.method_5477().getString();
            }
        }
        return null;
    }

    private static int listRules(CommandContext<class_2168> ctx) {
        for (String name : AmethystFarmSettings.ruleNames()) {
            AmethystFarmSettings.RuleDefinition rule = AmethystFarmSettings.findRule(name).orElseThrow();
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                name + " = " + rule.get() + " | " + rule.description() + " | " + rule.valueHint()
            ), false);
        }
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "使用 /" + PRIMARY_ROOT + " rule set <规则> <值> 修改，简写: /" + SHORT_ROOT
        ), false);
        return AmethystFarmSettings.ruleNames().size();
    }

    private static int getRule(CommandContext<class_2168> ctx, String name) {
        return AmethystFarmSettings.findRule(name).map(rule -> {
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                rule.id() + " = " + rule.get() + " | " + rule.description()
            ), false);
            return 1;
        }).orElseGet(() -> {
            ctx.getSource().method_9213(class_2561.method_43470("未知规则: " + name));
            return 0;
        });
    }

    private static int setRule(CommandContext<class_2168> ctx, String name, String value) {
        try {
            AmethystFarmSettings.setValue(name, value.trim());
            if (ctx.getSource().method_9211() != null) {
                AmethystFarmDataManager.save(ctx.getSource().method_9211());
                SettingsSyncHelper.broadcast(ctx.getSource().method_9211());
            }
            AmethystFarmSettings.RuleDefinition rule = AmethystFarmSettings.findRule(name).orElseThrow();
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                "规则 " + rule.id() + " 已设为 " + rule.get()
            ), true);
            return 1;
        } catch (IllegalArgumentException e) {
            ctx.getSource().method_9213(class_2561.method_43470("设置失败: " + e.getMessage()));
            return 0;
        }
    }

    private static boolean requireCarpet(CommandContext<class_2168> ctx) {
        if (AmethystFarmRuntime.isServerLogicEnabled()) {
            return true;
        }
        ctx.getSource().method_9213(class_2561.method_43470("此功能需要服务端安装 Carpet Mod"));
        return false;
    }

    private static int openGui(CommandContext<class_2168> ctx, class_3222 target) {
        if (!requireCarpet(ctx)) {
            return 0;
        }
        if (!CarpetHooks.isFakePlayer(target)) {
            ctx.getSource().method_9213(class_2561.method_43470("目标必须是 Carpet 假人，请先用 /player <name> spawn 生成"));
            return 0;
        }
        if (!(ctx.getSource().method_9228() instanceof class_3222 opener)) {
            ctx.getSource().method_9213(class_2561.method_43470("必须由玩家打开 GUI"));
            return 0;
        }
        if (!ModClientSupport.hasClientMod(opener)) {
            ctx.getSource().method_9213(class_2561.method_43470(
                "打开 GUI 需要客户端安装 amethystfarm 模组，无模组玩家请使用 /af 命令"
            ));
            return 0;
        }
        AmethystFarmMenus.open(opener, target);
        ctx.getSource().method_9226(() -> class_2561.method_43470("已打开假人 " + target.method_5477().getString() + " 的紫水晶农场控制面板"), false);
        return 1;
    }

    private static int startHarvest(CommandContext<class_2168> ctx, class_3222 target) {
        if (!requireCarpet(ctx) || !requireFake(ctx, target)) {
            return 0;
        }
        AmethystHarvester.applyWorkMode(target, AmethystFarmDataManager.get(target), WorkMode.HARVEST);
        persistProfiles(ctx);
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "已启用假人 " + target.method_5477().getString() + " 的紫水晶挖掘（HARVEST 模式）"
        ), true);
        return 1;
    }

    private static int stopFake(CommandContext<class_2168> ctx, class_3222 target) {
        return disableBot(ctx, target);
    }

    private static int enableBot(CommandContext<class_2168> ctx, class_3222 target) {
        if (!requireCarpet(ctx) || !requireFake(ctx, target)) {
            return 0;
        }
        AmethystFarmProfile profile = AmethystFarmDataManager.get(target);
        AmethystHarvester.enableBot(profile);
        persistProfiles(ctx);
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "已启用假人 " + target.method_5477().getString() + " 的紫水晶农场控制（当前模式: "
                + profile.getWorkMode().getDisplayName() + "）"
        ), true);
        return 1;
    }

    private static int disableBot(CommandContext<class_2168> ctx, class_3222 target) {
        if (!requireFake(ctx, target)) {
            return 0;
        }
        AmethystHarvester.disableBot(target, AmethystFarmDataManager.get(target));
        persistProfiles(ctx);
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "已关闭假人 " + target.method_5477().getString() + " 的紫水晶农场控制，不再影响其 ActionPack"
        ), true);
        return 1;
    }

    private static boolean requireFake(CommandContext<class_2168> ctx, class_3222 target) {
        if (CarpetHooks.isFakePlayer(target)) {
            return true;
        }
        ctx.getSource().method_9213(class_2561.method_43470("目标必须是 Carpet 假人"));
        return false;
    }

    private static int setMode(CommandContext<class_2168> ctx, class_3222 target, String modeName) {
        if (!requireCarpet(ctx)) {
            return 0;
        }
        if (!CarpetHooks.isFakePlayer(target)) {
            ctx.getSource().method_9213(class_2561.method_43470("目标必须是 Carpet 假人"));
            return 0;
        }
        WorkMode mode;
        try {
            mode = WorkMode.fromString(modeName);
        } catch (IllegalArgumentException e) {
            ctx.getSource().method_9213(class_2561.method_43470("未知模式，可用: IDLE, SCAN, HARVEST, LOCK_MINE"));
            return 0;
        }
        AmethystFarmProfile profile = AmethystFarmDataManager.get(target);
        AmethystHarvester.applyWorkMode(target, profile, mode);
        persistProfiles(ctx);
        String enabledHint = profile.isBotEnabled() ? "（农场已启用）" : "（农场未启用，请 /af on 或 /af harvest）";
        ctx.getSource().method_9226(() -> class_2561.method_43470("假人 " + target.method_5477().getString()
            + " 工作模式已设为: " + mode.getDisplayName() + " — " + mode.getDescription() + enabledHint), true);
        return 1;
    }

    private static int showStatus(CommandContext<class_2168> ctx, class_3222 target) {
        if (!CarpetHooks.isFakePlayer(target)) {
            ctx.getSource().method_9213(class_2561.method_43470("目标必须是 Carpet 假人"));
            return 0;
        }
        AmethystFarmProfile profile = AmethystFarmDataManager.get(target);
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "假人: " + target.method_5477().getString()
                + " | 农场: " + (profile.isBotEnabled() ? "已启用" : "未启用")
                + " | 模式: " + profile.getWorkMode().getDisplayName()
                + " | 白名单: " + profile.getHarvestWhitelist().formatSummary().getString()
                + " | 扫描半径: " + AmethystFarmSettings.scanRadius
                + " | 手长: " + AmethystFarmSettings.miningReach
                + " | 母岩: " + profile.getBuddingCount()
                + " | 附近可挖: " + profile.getCrystalCount()
                + " | 手长内: " + profile.getReachableCrystalCount()
                + " | 成熟簇: " + profile.getClusterCount()
        ), false);
        return 1;
    }
}
