package com.zsj.amethystfarm.farm;

import carpet.fakes.ServerPlayerInterface;
import carpet.helpers.EntityPlayerActionPack;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5542;

/**
 * Breaks a specific block position without ActionPack ATTACK raycasts
 * (which often hit calcite or other blocks in front of amethyst buds).
 */
public final class AmethystBlockBreaker {
    private AmethystBlockBreaker() {}

    public static void abort(class_3222 fake, class_3218 level, AmethystFarmProfile profile) {
        stopAttackAction(fake);
        class_2338 breaking = profile.getBreakingBlockPos();
        if (breaking != null) {
            fake.field_13974.method_14263(
                breaking,
                class_2846.class_2847.field_12971,
                class_2350.field_11033,
                level.method_31600(),
                0
            );
            level.method_8517(-1, breaking, -1);
        }
        profile.clearBreakingState();
    }

    /**
     * @return true when the target block is gone or breaking finished this tick
     */
    public static boolean tickBreak(
        class_3222 fake,
        class_3218 level,
        AmethystFarmProfile profile,
        class_2338 target,
        HarvestWhitelist whitelist
    ) {
        stopAttackAction(fake);

        class_2680 state = level.method_8320(target);
        if (!AmethystCrystalHelper.matchesHarvestWhitelist(state, level, target, whitelist)) {
            abort(fake, level, profile);
            return true;
        }

        class_2350 face = breakFace(state, fake, target);
        actionPack(fake).lookAt(lookPoint(state, target));

        if (fake.field_13974.method_14257().method_8386()) {
            fake.field_13974.method_14263(
                target,
                class_2846.class_2847.field_12968,
                face,
                level.method_31600(),
                0
            );
            fake.method_6104(class_1268.field_5808);
            profile.clearBreakingState();
            return true;
        }

        if (profile.getBlockHitDelay() > 0) {
            profile.setBlockHitDelay(profile.getBlockHitDelay() - 1);
            return false;
        }

        class_2338 breaking = profile.getBreakingBlockPos();
        if (breaking == null || !breaking.equals(target)) {
            if (breaking != null) {
                fake.field_13974.method_14263(
                    breaking,
                    class_2846.class_2847.field_12971,
                    face,
                    level.method_31600(),
                    0
                );
                level.method_8517(-1, breaking, -1);
            }
            fake.field_13974.method_14263(
                target,
                class_2846.class_2847.field_12968,
                face,
                level.method_31600(),
                0
            );
            profile.setBreakingBlockPos(target);
            profile.setBlockBreakDamage(0.0f);
            if (!state.method_26215()) {
                state.method_26179(level, target, fake);
            }
            fake.method_6104(class_1268.field_5808);
            fake.method_14234();
            return false;
        }

        float progress = state.method_26165(fake, level, target);
        profile.addBlockBreakDamage(progress);
        level.method_8517(-1, target, (int) (profile.getBlockBreakDamage() * 10.0f));
        fake.method_6104(class_1268.field_5808);
        fake.method_14234();

        if (profile.getBlockBreakDamage() >= 1.0f) {
            fake.field_13974.method_14263(
                target,
                class_2846.class_2847.field_12973,
                face,
                level.method_31600(),
                0
            );
            level.method_8517(-1, target, -1);
            profile.clearBreakingState();
            profile.setBlockHitDelay(5);
            return true;
        }
        return false;
    }

    /** Outward face of attached buds/clusters — avoids aiming into the geode wall. */
    static class_243 lookPoint(class_2680 state, class_2338 target) {
        class_243 center = class_243.method_24953(target);
        if (state.method_28498(class_5542.field_27087)) {
            class_2350 outward = state.method_11654(class_5542.field_27087);
            return center.method_1031(
                outward.method_10148() * 0.48,
                outward.method_10164() * 0.48,
                outward.method_10165() * 0.48
            );
        }
        return center;
    }

    static class_2350 breakFace(class_2680 state, class_3222 fake, class_2338 target) {
        if (state.method_28498(class_5542.field_27087)) {
            return state.method_11654(class_5542.field_27087);
        }
        class_243 eye = fake.method_33571();
        class_243 center = class_243.method_24953(target);
        class_243 delta = center.method_1020(eye);
        if (delta.method_1027() < 1.0E-6) {
            return class_2350.field_11036;
        }
        return class_2350.method_10142(delta.field_1352, delta.field_1351, delta.field_1350);
    }

    private static void stopAttackAction(class_3222 fake) {
        actionPack(fake).start(EntityPlayerActionPack.ActionType.ATTACK, null);
    }

    private static EntityPlayerActionPack actionPack(class_3222 fake) {
        return ((ServerPlayerInterface) fake).getActionPack();
    }
}
