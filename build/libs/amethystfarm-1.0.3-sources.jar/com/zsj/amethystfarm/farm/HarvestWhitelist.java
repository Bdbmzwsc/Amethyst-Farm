package com.zsj.amethystfarm.farm;

import net.minecraft.class_2487;
import net.minecraft.class_2561;

public final class HarvestWhitelist {
    private boolean smallBud = true;
    private boolean mediumBud = true;
    private boolean largeBud = true;
    private boolean cluster = true;
    /** When true, only harvest crystals on horizontal faces of budding amethyst (not top/bottom). */
    private boolean sidesOnly = true;

    public boolean isSmallBud() {
        return smallBud;
    }

    public void setSmallBud(boolean enabled) {
        this.smallBud = enabled;
    }

    public void toggleSmallBud() {
        smallBud = !smallBud;
    }

    public boolean isMediumBud() {
        return mediumBud;
    }

    public void setMediumBud(boolean enabled) {
        this.mediumBud = enabled;
    }

    public void toggleMediumBud() {
        mediumBud = !mediumBud;
    }

    public boolean isLargeBud() {
        return largeBud;
    }

    public void setLargeBud(boolean enabled) {
        this.largeBud = enabled;
    }

    public void toggleLargeBud() {
        largeBud = !largeBud;
    }

    public boolean isCluster() {
        return cluster;
    }

    public void setCluster(boolean enabled) {
        this.cluster = enabled;
    }

    public void toggleCluster() {
        cluster = !cluster;
    }

    public boolean isSidesOnly() {
        return sidesOnly;
    }

    public void setSidesOnly(boolean enabled) {
        this.sidesOnly = enabled;
    }

    public void toggleSidesOnly() {
        sidesOnly = !sidesOnly;
    }

    public boolean hasAnyTypeEnabled() {
        return smallBud || mediumBud || largeBud || cluster;
    }

    public class_2561 formatSummary() {
        StringBuilder sb = new StringBuilder();
        if (smallBud) {
            sb.append("小芽");
        }
        if (mediumBud) {
            if (!sb.isEmpty()) {
                sb.append("/");
            }
            sb.append("中芽");
        }
        if (largeBud) {
            if (!sb.isEmpty()) {
                sb.append("/");
            }
            sb.append("大芽");
        }
        if (cluster) {
            if (!sb.isEmpty()) {
                sb.append("/");
            }
            sb.append("簇");
        }
        if (sb.isEmpty()) {
            sb.append("无");
        }
        if (sidesOnly) {
            sb.append(" | 仅侧面");
        }
        return class_2561.method_43470(sb.toString());
    }

    public class_2487 save() {
        class_2487 tag = new class_2487();
        tag.method_10556("smallBud", smallBud);
        tag.method_10556("mediumBud", mediumBud);
        tag.method_10556("largeBud", largeBud);
        tag.method_10556("cluster", cluster);
        tag.method_10556("sidesOnly", sidesOnly);
        return tag;
    }

    public void load(class_2487 tag) {
        smallBud = tag.method_10577("smallBud").orElse(true);
        mediumBud = tag.method_10577("mediumBud").orElse(true);
        largeBud = tag.method_10577("largeBud").orElse(true);
        cluster = tag.method_10577("cluster").orElse(true);
        sidesOnly = tag.method_10577("sidesOnly").orElse(true);
    }
}
