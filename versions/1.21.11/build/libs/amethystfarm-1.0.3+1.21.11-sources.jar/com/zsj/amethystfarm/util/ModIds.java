package com.zsj.amethystfarm.util;

public final class ModIds {
    private ModIds() {}

    //? if >=1.21.11 {
    public static net.minecraft.class_2960 id(String namespace, String path) {
        return net.minecraft.class_2960.method_60655(namespace, path);
    }

    public static net.minecraft.class_2960 parse(String value) {
        return net.minecraft.class_2960.method_60654(value);
    }
    //?} else {
    /*public static net.minecraft.resources.ResourceLocation id(String namespace, String path) {
        return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(namespace, path);
    }

    public static net.minecraft.resources.ResourceLocation parse(String value) {
        return net.minecraft.resources.ResourceLocation.parse(value);
    }
    *///?}
}
