package com.zsj.amethystfarm.client.gui;

import com.zsj.amethystfarm.gui.AmethystFarmMenu;
import net.minecraft.class_11909;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;

public class AmethystFarmScreen extends class_465<AmethystFarmMenu> {
    private static final int TITLE_COLOR = 0xFFE1BEE7;
    private static final int SECTION_COLOR = 0xFFCE93D8;
    private static final int HINT_COLOR = 0xFFAAAAAA;
    private static final int INVENTORY_COLOR = 0xFF404040;

    public AmethystFarmScreen(AmethystFarmMenu menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        this.field_2779 = 184;
        this.field_25267 = 8;
        this.field_25268 = 6;
        this.field_25270 = 82;
    }

    //? if >=1.21.9 {
    @Override
    public boolean method_25402(class_11909 event, boolean doubled) {
        int button = event.method_74245();
        if (handleButtonClick(event.comp_4798(), event.comp_4799(), button)) {
            return true;
        }
        return super.method_25402(event, doubled);
    }
    //?} else {
    /*@Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (handleButtonClick(mouseX, mouseY, button)) {
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
    *///?}

    @Override
    protected void method_2383(class_1735 slot, int slotId, int mouseButton, class_1713 clickType) {
        if (slotId >= 0 && slotId < AmethystFarmMenu.SLOT_COUNT) {
            sendButtonSlotClick(slot, mouseButton, clickType);
            return;
        }
        super.method_2383(slot, slotId, mouseButton, clickType);
    }

    private boolean handleButtonClick(double mouseX, double mouseY, int button) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT || button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
            class_1735 slot = findButtonSlotAt(mouseX, mouseY);
            if (slot != null) {
                sendButtonSlotClick(slot, button, class_1713.field_7790);
                return true;
            }
        }
        return false;
    }

    private class_1735 findButtonSlotAt(double mouseX, double mouseY) {
        if (isButtonSlot(field_2787)) {
            return field_2787;
        }
        for (int i = 0; i < AmethystFarmMenu.SLOT_COUNT && i < field_2797.field_7761.size(); i++) {
            class_1735 slot = field_2797.field_7761.get(i);
            if (isMouseOverSlot(slot, mouseX, mouseY)) {
                return slot;
            }
        }
        return null;
    }

    private boolean isMouseOverSlot(class_1735 slot, double mouseX, double mouseY) {
        return method_2378(slot.field_7873, slot.field_7872, 16, 16, mouseX, mouseY);
    }

    private boolean isButtonSlot(class_1735 slot) {
        if (slot == null) {
            return false;
        }
        int index = field_2797.field_7761.indexOf(slot);
        return index >= 0 && index < AmethystFarmMenu.SLOT_COUNT;
    }

    private void sendButtonSlotClick(class_1735 slot, int mouseButton, class_1713 clickType) {
        class_310 client = class_310.method_1551();
        if (client.field_1761 == null || client.field_1724 == null) {
            return;
        }
        int slotId = field_2797.field_7761.indexOf(slot);
        if (slotId < 0 || slotId >= AmethystFarmMenu.SLOT_COUNT) {
            return;
        }
        client.field_1761.method_2906(
            field_2797.field_7763,
            slotId,
            mouseButton,
            clickType,
            client.field_1724
        );
        client.field_1724.method_43077(class_3417.field_15015.comp_349());
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
        int x = field_2776;
        int y = field_2800;
        graphics.method_25294(x, y, x + field_2792, y + field_2779, 0xC0101010);
        graphics.method_25294(x + 6, y + 6, x + field_2792 - 6, y + 88, 0xFF2A1240);
    }

    @Override
    protected void method_2388(class_332 graphics, int mouseX, int mouseY) {
        graphics.method_51439(field_22793, field_22785, field_25267, field_25268, TITLE_COLOR, false);
        graphics.method_51439(field_22793, class_2561.method_43470("\u5de5\u4f5c\u6a21\u5f0f / \u519c\u573a\u603b\u5f00\u5173"), 8, 17, SECTION_COLOR, false);
        graphics.method_51439(field_22793, class_2561.method_43470("\u6316\u6398\u767d\u540d\u5355\uff08\u70b9\u51fb\u5207\u6362\uff09"), 8, 47, SECTION_COLOR, false);
        graphics.method_51439(field_22793, class_2561.method_43470("\u4ec5\u4fa7\u9762\uff1a\u53ea\u6316\u6bcd\u5ca9\u56db\u4fa7"), 8, 75, HINT_COLOR, false);
        graphics.method_51439(field_22793, field_29347, field_25269, field_25270, INVENTORY_COLOR, false);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        method_2380(graphics, mouseX, mouseY);
    }
}
