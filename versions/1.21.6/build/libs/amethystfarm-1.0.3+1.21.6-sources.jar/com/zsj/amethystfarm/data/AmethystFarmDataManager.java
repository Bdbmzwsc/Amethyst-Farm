package com.zsj.amethystfarm.data;

import com.zsj.amethystfarm.AmethystFarmMod;
import com.zsj.amethystfarm.CarpetHooks;
import com.zsj.amethystfarm.config.AmethystFarmSettings;
import com.zsj.amethystfarm.fakes.AmethystFarmBotAccess;
import com.zsj.amethystfarm.farm.AmethystFarmProfile;
import com.zsj.amethystfarm.util.ModCompat;
import com.zsj.amethystfarm.util.NbtCompat;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_3222;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class AmethystFarmDataManager {
    private static final String BY_NAME_KEY = "byName";

    private static final Map<UUID, AmethystFarmProfile> PROFILES = new HashMap<>();
    private static final Map<String, AmethystFarmProfile> PROFILES_BY_NAME = new HashMap<>();
    /** v1 saves keyed by UUID, merged into byName when matching fake joins. */
    private static final Map<UUID, AmethystFarmProfile> LEGACY_UUID_PROFILES = new HashMap<>();

    private AmethystFarmDataManager() {}

    public static void init() {}

    public static AmethystFarmProfile getOrCreate(class_3222 player) {
        AmethystFarmProfile profile = PROFILES.get(player.method_5667());
        if (profile != null) {
            return profile;
        }
        return resolveProfile(player);
    }

    public static AmethystFarmProfile get(class_3222 player) {
        if (player instanceof AmethystFarmBotAccess access) {
            return access.amethystfarm$getProfile();
        }
        return getOrCreate(player);
    }

    public static void onFakePlayerJoin(class_3222 player) {
        if (!CarpetHooks.isFakePlayer(player)) {
            return;
        }
        // Only restore a saved profile; never create one on join (avoids touching unrelated fakes).
        String name = ModCompat.profileName(player.method_7334());
        AmethystFarmProfile saved = PROFILES_BY_NAME.get(name);
        if (saved != null) {
            PROFILES.put(player.method_5667(), saved);
        }
    }

    /** True when this fake is under farm control and may tick harvest logic. */
    public static boolean isFarmActive(class_3222 player) {
        if (!CarpetHooks.isFakePlayer(player)) {
            return false;
        }
        AmethystFarmProfile profile = PROFILES.get(player.method_5667());
        if (profile == null) {
            profile = PROFILES_BY_NAME.get(ModCompat.profileName(player.method_7334()));
        }
        return profile != null && profile.isBotEnabled();
    }

    public static void onFakePlayerLeave(class_3222 player) {
        if (!CarpetHooks.isFakePlayer(player)) {
            return;
        }
        String name = ModCompat.profileName(player.method_7334());
        AmethystFarmProfile profile = PROFILES.get(player.method_5667());
        if (profile != null) {
            PROFILES_BY_NAME.put(name, profile);
        }
        PROFILES.remove(player.method_5667());
    }

    private static AmethystFarmProfile resolveProfile(class_3222 player) {
        UUID uuid = player.method_5667();
        String name = ModCompat.profileName(player.method_7334());

        AmethystFarmProfile profile = PROFILES_BY_NAME.get(name);
        if (profile == null) {
            profile = LEGACY_UUID_PROFILES.remove(uuid);
        }
        if (profile == null) {
            profile = new AmethystFarmProfile();
        }

        if (CarpetHooks.isFakePlayer(player)) {
            PROFILES_BY_NAME.put(name, profile);
        }
        PROFILES.put(uuid, profile);
        return profile;
    }

    public static void syncOnlineFakeProfiles(MinecraftServer server) {
        for (class_3222 player : CarpetHooks.getOnlineFakePlayers(server)) {
            String name = ModCompat.profileName(player.method_7334());
            AmethystFarmProfile profile = get(player);
            PROFILES_BY_NAME.put(name, profile);
            PROFILES.put(player.method_5667(), profile);
        }
    }

    public static Map<String, AmethystFarmProfile> getProfilesByName() {
        return PROFILES_BY_NAME;
    }

    public static void save(MinecraftServer server) {
        saveProfiles(server);
        saveSettings(server);
    }

    public static void persistProfiles(MinecraftServer server) {
        if (server != null) {
            syncOnlineFakeProfiles(server);
            saveProfiles(server);
        }
    }

    public static void load(MinecraftServer server) {
        loadSettings(server);
        loadProfiles(server);
    }

    private static void saveProfiles(MinecraftServer server) {
        syncOnlineFakeProfiles(server);
        class_2487 root = new class_2487();
        class_2487 byName = new class_2487();
        PROFILES_BY_NAME.forEach((name, profile) -> byName.method_10566(name, profile.save()));
        root.method_10566(BY_NAME_KEY, byName);
        try {
            Path path = profilesPath(server);
            Files.createDirectories(path.getParent());
            class_2507.method_30614(root, path);
        } catch (IOException e) {
            AmethystFarmMod.LOGGER.error("Failed to save amethyst farm profiles", e);
        }
    }

    private static void loadProfiles(MinecraftServer server) {
        PROFILES.clear();
        PROFILES_BY_NAME.clear();
        LEGACY_UUID_PROFILES.clear();
        Path path = profilesPath(server);
        if (!Files.exists(path)) {
            return;
        }
        try {
            class_2487 root = class_2507.method_30613(path, class_2505.method_53898());
            if (root.method_10545(BY_NAME_KEY)) {
                class_2487 byName = NbtCompat.readCompoundOrEmpty(root, BY_NAME_KEY);
                for (String name : NbtCompat.tagKeys(byName)) {
                    AmethystFarmProfile profile = new AmethystFarmProfile();
                    NbtCompat.readCompound(byName, name, profile::load);
                    PROFILES_BY_NAME.put(name, profile);
                }
            } else {
                loadLegacyUuidProfiles(root);
            }
        } catch (IOException e) {
            AmethystFarmMod.LOGGER.error("Failed to load amethyst farm profiles", e);
        }

        for (class_3222 player : CarpetHooks.getOnlineFakePlayers(server)) {
            onFakePlayerJoin(player);
        }
    }

    private static void loadLegacyUuidProfiles(class_2487 root) {
        for (String key : NbtCompat.tagKeys(root)) {
            try {
                UUID uuid = UUID.fromString(key);
                AmethystFarmProfile profile = new AmethystFarmProfile();
                NbtCompat.readCompound(root, key, profile::load);
                LEGACY_UUID_PROFILES.put(uuid, profile);
            } catch (IllegalArgumentException ignored) {
                // not a UUID key
            }
        }
        if (!LEGACY_UUID_PROFILES.isEmpty()) {
            AmethystFarmMod.LOGGER.info(
                "Loaded {} legacy UUID profile(s); will restore when matching fake player joins",
                LEGACY_UUID_PROFILES.size()
            );
        }
    }

    private static void saveSettings(MinecraftServer server) {
        try {
            Path path = settingsPath(server);
            Files.createDirectories(path.getParent());
            class_2507.method_30614(AmethystFarmSettings.save(), path);
        } catch (IOException e) {
            AmethystFarmMod.LOGGER.error("Failed to save amethyst farm settings", e);
        }
    }

    private static void loadSettings(MinecraftServer server) {
        Path path = settingsPath(server);
        if (!Files.exists(path)) {
            return;
        }
        try {
            class_2487 tag = class_2507.method_30613(path, class_2505.method_53898());
            AmethystFarmSettings.load(tag);
        } catch (IOException e) {
            AmethystFarmMod.LOGGER.error("Failed to load amethyst farm settings", e);
        }
    }

    private static Path profilesPath(MinecraftServer server) {
        return server.method_27050(class_5218.field_24188).resolve("data/amethystfarm_profiles.dat");
    }

    private static Path settingsPath(MinecraftServer server) {
        return server.method_27050(class_5218.field_24188).resolve("data/amethystfarm_settings.dat");
    }
}
