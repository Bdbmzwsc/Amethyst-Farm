package com.zsj.amethystfarm.client.render;

import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;

public record CachedCrystalOutline(class_2338 pos, class_238 localBounds, boolean mature) {
    public class_238 worldBounds() {
        return localBounds.method_996(pos);
    }

    public double distanceSquaredTo(class_243 point) {
        return worldBounds().method_1005().method_1025(point);
    }
}
