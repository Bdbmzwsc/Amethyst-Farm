package com.zsj.amethystfarm.farm;

import com.zsj.amethystfarm.util.NbtCompat;
import net.minecraft.class_2338;
import net.minecraft.class_2487;

public class AmethystFarmProfile {
    private WorkMode workMode = WorkMode.IDLE;
    /** When false this fake is ignored entirely and Carpet ActionPack is not touched. */
    private boolean botEnabled = false;
    private final HarvestWhitelist harvestWhitelist = new HarvestWhitelist();
    private class_2338 lockedTarget = null;
    private int tickCounter;
    private int buddingCount;
    private int crystalCount;
    private int clusterCount;
    private int reachableCrystalCount;
    private boolean scanPreviewActive;
    private class_2338 miningTarget;
    private boolean miningAttackActive;
    private boolean tickPhaseInitialized;
    private class_2338 breakingBlockPos;
    private float blockBreakDamage;
    private int blockHitDelay;

    public WorkMode getWorkMode() {
        return workMode;
    }

    public void setWorkMode(WorkMode workMode) {
        this.workMode = workMode;
        if (workMode != WorkMode.LOCK_MINE) {
            lockedTarget = null;
        }
    }

    public boolean isBotEnabled() {
        return botEnabled;
    }

    public void setBotEnabled(boolean botEnabled) {
        this.botEnabled = botEnabled;
    }

    public HarvestWhitelist getHarvestWhitelist() {
        return harvestWhitelist;
    }

    public class_2338 getLockedTarget() {
        return lockedTarget;
    }

    public void setLockedTarget(class_2338 lockedTarget) {
        this.lockedTarget = lockedTarget == null ? null : lockedTarget.method_10062();
    }

    public int getTickCounter() {
        return tickCounter;
    }

    public void setTickCounter(int tickCounter) {
        this.tickCounter = tickCounter;
    }

    public int getBuddingCount() {
        return buddingCount;
    }

    public void setBuddingCount(int buddingCount) {
        this.buddingCount = buddingCount;
    }

    public int getCrystalCount() {
        return crystalCount;
    }

    public void setCrystalCount(int crystalCount) {
        this.crystalCount = crystalCount;
    }

    public int getClusterCount() {
        return clusterCount;
    }

    public void setClusterCount(int clusterCount) {
        this.clusterCount = clusterCount;
    }

    public int getReachableCrystalCount() {
        return reachableCrystalCount;
    }

    public void setReachableCrystalCount(int reachableCrystalCount) {
        this.reachableCrystalCount = reachableCrystalCount;
    }

    public void ensureTickPhase(java.util.UUID botId, int interval) {
        if (!tickPhaseInitialized) {
            tickCounter = Math.floorMod(botId.hashCode(), Math.max(1, interval));
            tickPhaseInitialized = true;
        }
    }

    public void markScanPreviewActive() {
        scanPreviewActive = true;
    }

    public boolean clearScanPreviewIfNeeded() {
        if (scanPreviewActive) {
            scanPreviewActive = false;
            return true;
        }
        return false;
    }

    public class_2338 getMiningTarget() {
        return miningTarget;
    }

    public void setMiningTarget(class_2338 target) {
        this.miningTarget = target == null ? null : target.method_10062();
    }

    public boolean clearMiningTargetIfNeeded() {
        if (miningTarget != null) {
            miningTarget = null;
            return true;
        }
        return false;
    }

    public boolean isMiningAttackActive() {
        return miningAttackActive;
    }

    public void setMiningAttackActive(boolean active) {
        this.miningAttackActive = active;
    }

    public void clearMiningAttack() {
        miningAttackActive = false;
    }

    public class_2338 getBreakingBlockPos() {
        return breakingBlockPos;
    }

    public void setBreakingBlockPos(class_2338 pos) {
        this.breakingBlockPos = pos == null ? null : pos.method_10062();
    }

    public float getBlockBreakDamage() {
        return blockBreakDamage;
    }

    public void setBlockBreakDamage(float damage) {
        this.blockBreakDamage = damage;
    }

    public void addBlockBreakDamage(float delta) {
        this.blockBreakDamage += delta;
    }

    public int getBlockHitDelay() {
        return blockHitDelay;
    }

    public void setBlockHitDelay(int delay) {
        this.blockHitDelay = delay;
    }

    public void clearBreakingState() {
        breakingBlockPos = null;
        blockBreakDamage = 0.0f;
    }

    public class_2487 save() {
        class_2487 tag = new class_2487();
        tag.method_10582("mode", workMode.name());
        tag.method_10556("botEnabled", botEnabled);
        tag.method_10566("harvestWhitelist", harvestWhitelist.save());
        if (lockedTarget != null) {
            tag.method_10544("lockedTarget", lockedTarget.method_10063());
        }
        return tag;
    }

    public void load(class_2487 tag) {
        NbtCompat.readString(tag, "mode", value -> workMode = WorkMode.valueOf(value));
        if (tag.method_10545("botEnabled")) {
            botEnabled = NbtCompat.readBoolean(tag, "botEnabled", false);
        } else {
            botEnabled = workMode != WorkMode.IDLE;
        }
        NbtCompat.readCompound(tag, "harvestWhitelist", harvestWhitelist::load);
        NbtCompat.readLong(tag, "lockedTarget", value -> lockedTarget = class_2338.method_10092(value));
    }
}
