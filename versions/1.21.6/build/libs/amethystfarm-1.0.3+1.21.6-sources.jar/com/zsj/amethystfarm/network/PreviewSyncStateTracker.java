package com.zsj.amethystfarm.network;

import com.zsj.amethystfarm.farm.AmethystCrystalHelper;
import com.zsj.amethystfarm.farm.AmethystFarmBinding;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public final class PreviewSyncStateTracker {
    private static final ConcurrentHashMap<Integer, PreviewState> STATES = new ConcurrentHashMap<>();

    private PreviewSyncStateTracker() {}

    public static void clear(int entityId) {
        STATES.remove(entityId);
    }

    public static Optional<PreviewSyncPayload> buildUpdate(
        int entityId,
        AmethystFarmBinding binding,
        List<class_2338> crystals,
        class_3218 level
    ) {
        class_2338 origin = binding.getMin();
        class_2338 max = binding.getMax();
        class_2338 extent = new class_2338(
            max.method_10263() - origin.method_10263(),
            max.method_10264() - origin.method_10264(),
            max.method_10260() - origin.method_10260()
        );

        Set<class_2338> current = new HashSet<>(crystals);
        PreviewState state = STATES.computeIfAbsent(entityId, ignored -> new PreviewState());

        boolean bindingChanged = !origin.equals(state.origin) || !extent.equals(state.extent);
        if (bindingChanged || state.crystals.isEmpty()) {
            state.origin = origin;
            state.extent = extent;
            state.crystals = current;
            return Optional.of(PreviewSyncPayload.full(entityId, origin, extent, toEntries(origin, current, level)));
        }

        if (state.crystals.equals(current)) {
            return Optional.empty();
        }

        Set<class_2338> added = new HashSet<>(current);
        added.removeAll(state.crystals);
        Set<class_2338> removed = new HashSet<>(state.crystals);
        removed.removeAll(current);
        state.crystals = current;

        if (added.size() + removed.size() > Math.max(1, current.size()) * 0.6) {
            return Optional.of(PreviewSyncPayload.full(entityId, origin, extent, toEntries(origin, current, level)));
        }

        return Optional.of(PreviewSyncPayload.delta(
            entityId,
            origin,
            toEntries(origin, added, level),
            toRelative(origin, removed)
        ));
    }

    private static List<PreviewSyncPayload.CrystalEntry> toEntries(class_2338 origin, Set<class_2338> positions, class_3218 level) {
        List<PreviewSyncPayload.CrystalEntry> entries = new ArrayList<>(positions.size());
        for (class_2338 pos : positions) {
            class_2680 state = level.method_8320(pos);
            entries.add(new PreviewSyncPayload.CrystalEntry(
                pos.method_10263() - origin.method_10263(),
                pos.method_10264() - origin.method_10264(),
                pos.method_10260() - origin.method_10260(),
                AmethystCrystalHelper.isMatureCluster(state)
            ));
        }
        return entries;
    }

    private static List<class_2338> toRelative(class_2338 origin, Set<class_2338> positions) {
        List<class_2338> relative = new ArrayList<>(positions.size());
        for (class_2338 pos : positions) {
            relative.add(new class_2338(
                pos.method_10263() - origin.method_10263(),
                pos.method_10264() - origin.method_10264(),
                pos.method_10260() - origin.method_10260()
            ));
        }
        return relative;
    }

    private static final class PreviewState {
        private class_2338 origin = class_2338.field_10980;
        private class_2338 extent = class_2338.field_10980;
        private Set<class_2338> crystals = Set.of();
    }
}
