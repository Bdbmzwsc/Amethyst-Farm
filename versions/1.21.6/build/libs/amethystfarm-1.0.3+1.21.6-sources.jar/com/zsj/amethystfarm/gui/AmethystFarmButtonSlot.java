package com.zsj.amethystfarm.gui;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class AmethystFarmButtonSlot extends class_1735 {
    public AmethystFarmButtonSlot(class_1263 container, int index, int x, int y) {
        super(container, index, x, y);
    }

    @Override
    public boolean method_7674(class_1657 player) {
        return false;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return false;
    }

    @Override
    public boolean method_32754(class_1657 player) {
        return true;
    }
}
