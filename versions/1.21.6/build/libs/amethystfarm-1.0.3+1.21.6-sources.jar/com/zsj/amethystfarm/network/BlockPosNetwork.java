package com.zsj.amethystfarm.network;

import net.minecraft.class_2338;
import net.minecraft.class_2540;

public final class BlockPosNetwork {
    private BlockPosNetwork() {}

    public static void writeBlockPos(class_2540 buf, class_2338 pos) {
        buf.method_10804(pos.method_10263());
        buf.method_10804(pos.method_10264());
        buf.method_10804(pos.method_10260());
    }

    public static class_2338 readBlockPos(class_2540 buf) {
        return new class_2338(buf.method_10816(), buf.method_10816(), buf.method_10816());
    }

    public static void writeRelative(class_2540 buf, class_2338 origin, class_2338 pos) {
        buf.method_10804(pos.method_10263() - origin.method_10263());
        buf.method_10804(pos.method_10264() - origin.method_10264());
        buf.method_10804(pos.method_10260() - origin.method_10260());
    }

    public static class_2338 readRelative(class_2540 buf, class_2338 origin) {
        return origin.method_10069(buf.method_10816(), buf.method_10816(), buf.method_10816());
    }
}
