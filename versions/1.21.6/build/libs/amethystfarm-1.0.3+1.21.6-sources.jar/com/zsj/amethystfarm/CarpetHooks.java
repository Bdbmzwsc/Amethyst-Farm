package com.zsj.amethystfarm;

import net.minecraft.class_3222;

public final class CarpetHooks {
    private static final String FAKE_PLAYER_CLASS = "carpet.patches.EntityPlayerMPFake";

    private CarpetHooks() {}

    public static boolean isFakePlayer(class_3222 player) {
        return AmethystFarmRuntime.isCarpetLoaded()
            && FAKE_PLAYER_CLASS.equals(player.getClass().getName());
    }

    public static java.util.List<class_3222> getOnlineFakePlayers(net.minecraft.server.MinecraftServer server) {
        return server.method_3760().method_14571().stream()
            .filter(CarpetHooks::isFakePlayer)
            .toList();
    }
}
