package com.zsj.amethystfarm.network;

import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public final class SettingsSyncHelper {
    private SettingsSyncHelper() {}

    public static void sendToPlayer(class_3222 player) {
        NetworkBroadcast.sendToPlayer(player, SettingsSyncPayload.fromSettings(), SettingsSyncPayload.TYPE);
    }

    public static void broadcast(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            sendToPlayer(player);
        }
    }
}
