package com.zsj.amethystfarm.farm;

import com.zsj.amethystfarm.util.ModCompat;
import com.zsj.amethystfarm.util.ModIds;
import com.zsj.amethystfarm.util.NbtCompat;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class AmethystFarmBinding {
    public static final AmethystFarmBinding EMPTY = new AmethystFarmBinding();

    private class_2338 pos1 = class_2338.field_10980;
    private class_2338 pos2 = class_2338.field_10980;
    private boolean bound;
    private class_5321<class_1937> dimension;

    public class_2338 getPos1() {
        return pos1;
    }

    public class_2338 getPos2() {
        return pos2;
    }

    public boolean isBound() {
        return bound;
    }

    public class_5321<class_1937> getDimension() {
        return dimension;
    }

    public void setCorner1(class_2338 pos, class_5321<class_1937> dimension) {
        this.pos1 = pos.method_10062();
        this.dimension = dimension;
        updateBound();
    }

    public void setCorner2(class_2338 pos, class_5321<class_1937> dimension) {
        this.pos2 = pos.method_10062();
        this.dimension = dimension;
        updateBound();
    }

    public void setRange(class_2338 from, class_2338 to, class_5321<class_1937> dimension) {
        this.pos1 = from.method_10062();
        this.pos2 = to.method_10062();
        this.dimension = dimension;
        updateBound();
    }

    public void clear() {
        pos1 = class_2338.field_10980;
        pos2 = class_2338.field_10980;
        bound = false;
        dimension = null;
    }

    public class_2338 getMin() {
        return new class_2338(
            Math.min(pos1.method_10263(), pos2.method_10263()),
            Math.min(pos1.method_10264(), pos2.method_10264()),
            Math.min(pos1.method_10260(), pos2.method_10260())
        );
    }

    public class_2338 getMax() {
        return new class_2338(
            Math.max(pos1.method_10263(), pos2.method_10263()),
            Math.max(pos1.method_10264(), pos2.method_10264()),
            Math.max(pos1.method_10260(), pos2.method_10260())
        );
    }

    public long volume() {
        if (!bound) {
            return 0;
        }
        class_2338 min = getMin();
        class_2338 max = getMax();
        return (long) (max.method_10263() - min.method_10263() + 1)
            * (max.method_10264() - min.method_10264() + 1)
            * (max.method_10260() - min.method_10260() + 1);
    }

    private void updateBound() {
        bound = !pos1.equals(class_2338.field_10980) || !pos2.equals(class_2338.field_10980);
    }

    public class_2487 save() {
        class_2487 tag = new class_2487();
        tag.method_10544("pos1", pos1.method_10063());
        tag.method_10544("pos2", pos2.method_10063());
        tag.method_10556("bound", bound);
        if (dimension != null) {
            tag.method_10582("dimension", ModCompat.dimensionKey(dimension));
        }
        return tag;
    }

    public void load(class_2487 tag) {
        NbtCompat.readLong(tag, "pos1", value -> pos1 = class_2338.method_10092(value));
        NbtCompat.readLong(tag, "pos2", value -> pos2 = class_2338.method_10092(value));
        bound = NbtCompat.readBoolean(tag, "bound", false);
        NbtCompat.readString(tag, "dimension", value ->
            dimension = class_5321.method_29179(class_7924.field_41223, ModIds.parse(value))
        );
    }

    public void copyFrom(AmethystFarmBinding source) {
        load(source.save());
    }

    /** Builds a cubic scan bounds centered on {@code center} (used for nearby preview/sync). */
    public static AmethystFarmBinding around(class_2338 center, int radius, class_5321<class_1937> dimension) {
        AmethystFarmBinding binding = new AmethystFarmBinding();
        binding.setRange(
            center.method_10069(-radius, -radius, -radius),
            center.method_10069(radius, radius, radius),
            dimension
        );
        return binding;
    }
}
