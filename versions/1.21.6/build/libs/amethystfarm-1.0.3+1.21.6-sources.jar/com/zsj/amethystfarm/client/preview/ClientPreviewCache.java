package com.zsj.amethystfarm.client.preview;

import com.zsj.amethystfarm.client.render.CachedCrystalOutline;
import com.zsj.amethystfarm.farm.AmethystCrystalHelper;
import com.zsj.amethystfarm.network.PreviewSyncPayload;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class ClientPreviewCache {
    public record CrystalPreview(
        class_2338 origin,
        class_2338 extent,
        Map<class_2338, CachedCrystalOutline> crystals,
        long updatedAt
    ) {
        public class_2338 pos1() {
            return origin;
        }

        public class_2338 pos2() {
            return origin.method_10069(extent.method_10263(), extent.method_10264(), extent.method_10260());
        }

        public List<CachedCrystalOutline> crystalList() {
            return List.copyOf(crystals.values());
        }
    }

    private static final Map<Integer, CrystalPreview> PREVIEWS = new ConcurrentHashMap<>();

    private ClientPreviewCache() {}

    public static void apply(PreviewSyncPayload payload) {
        if (payload.action() == PreviewSyncPayload.CLEAR) {
            PREVIEWS.remove(payload.fakeEntityId());
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }

        switch (payload.action()) {
            case PreviewSyncPayload.FULL -> applyFull(client, payload);
            case PreviewSyncPayload.DELTA -> applyDelta(client, payload);
        }
    }

    private static void applyFull(class_310 client, PreviewSyncPayload payload) {
        Map<class_2338, CachedCrystalOutline> crystals = new HashMap<>();
        for (PreviewSyncPayload.CrystalEntry entry : payload.added()) {
            class_2338 pos = payload.origin().method_10069(entry.dx(), entry.dy(), entry.dz());
            CachedCrystalOutline outline = buildOutline(client, pos, entry.mature());
            if (outline != null) {
                crystals.put(pos, outline);
            }
        }

        PREVIEWS.put(payload.fakeEntityId(), new CrystalPreview(
            payload.origin(),
            payload.extent(),
            crystals,
            System.currentTimeMillis()
        ));
    }

    private static void applyDelta(class_310 client, PreviewSyncPayload payload) {
        CrystalPreview existing = PREVIEWS.get(payload.fakeEntityId());
        Map<class_2338, CachedCrystalOutline> crystals = existing != null
            ? new HashMap<>(existing.crystals())
            : new HashMap<>();

        class_2338 origin = payload.origin();
        for (class_2338 relative : payload.removedRelative()) {
            crystals.remove(origin.method_10069(relative.method_10263(), relative.method_10264(), relative.method_10260()));
        }
        for (PreviewSyncPayload.CrystalEntry entry : payload.added()) {
            class_2338 pos = origin.method_10069(entry.dx(), entry.dy(), entry.dz());
            CachedCrystalOutline outline = buildOutline(client, pos, entry.mature());
            if (outline != null) {
                crystals.put(pos, outline);
            } else {
                crystals.remove(pos);
            }
        }

        class_2338 extent = existing != null ? existing.extent() : class_2338.field_10980;
        PREVIEWS.put(payload.fakeEntityId(), new CrystalPreview(origin, extent, crystals, System.currentTimeMillis()));
    }

    private static CachedCrystalOutline buildOutline(class_310 client, class_2338 pos, boolean matureHint) {
        class_2680 state = client.field_1687.method_8320(pos);
        if (!AmethystCrystalHelper.isHarvestableCrystal(state)) {
            return null;
        }
        class_265 shape = state.method_26218(client.field_1687, pos);
        if (shape.method_1110()) {
            return null;
        }
        boolean mature = matureHint || AmethystCrystalHelper.isMatureCluster(state);
        return new CachedCrystalOutline(pos, shape.method_1107(), mature);
    }

    public static Map<Integer, CrystalPreview> all() {
        purgeMissingEntities();
        return PREVIEWS;
    }

    public static boolean isEmpty() {
        return PREVIEWS.isEmpty();
    }

    private static void purgeMissingEntities() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }
        Iterator<Map.Entry<Integer, CrystalPreview>> iterator = PREVIEWS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, CrystalPreview> entry = iterator.next();
            if (client.field_1687.method_8469(entry.getKey()) == null) {
                iterator.remove();
            }
        }
    }
}
