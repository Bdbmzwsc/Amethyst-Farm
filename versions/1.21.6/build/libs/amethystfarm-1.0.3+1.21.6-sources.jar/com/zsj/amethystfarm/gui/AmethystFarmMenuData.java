package com.zsj.amethystfarm.gui;

import java.util.UUID;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record AmethystFarmMenuData(UUID fakePlayerId) {
    public static final class_9139<class_9129, AmethystFarmMenuData> STREAM_CODEC = class_9139.method_56437(
        (buf, data) -> buf.method_10797(data.fakePlayerId()),
        buf -> new AmethystFarmMenuData(buf.method_10790())
    );
}
