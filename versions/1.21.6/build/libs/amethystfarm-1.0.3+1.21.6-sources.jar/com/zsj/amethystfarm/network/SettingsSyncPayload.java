package com.zsj.amethystfarm.network;

import com.zsj.amethystfarm.AmethystFarmMod;
import com.zsj.amethystfarm.config.AmethystFarmSettings;
import com.zsj.amethystfarm.util.ModIds;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record SettingsSyncPayload(float maxRenderDistance, int maxCrystalOutlines) implements class_8710 {
    public static final class_8710.class_9154<SettingsSyncPayload> TYPE =
        new class_8710.class_9154<>(ModIds.id(AmethystFarmMod.MOD_ID, "settings_sync"));

    public static final class_9139<class_2540, SettingsSyncPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_52941(payload.maxRenderDistance());
            buf.method_10804(payload.maxCrystalOutlines());
        },
        buf -> new SettingsSyncPayload(buf.readFloat(), buf.method_10816())
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static SettingsSyncPayload fromSettings() {
        return new SettingsSyncPayload(
            (float) AmethystFarmSettings.maxRenderDistance,
            AmethystFarmSettings.maxCrystalOutlines
        );
    }
}
