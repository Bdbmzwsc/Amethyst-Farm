package com.zsj.amethystfarm.network;

import com.zsj.amethystfarm.AmethystFarmMod;
import com.zsj.amethystfarm.util.ModIds;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record MiningTargetPayload(byte action, int fakeEntityId, class_2338 target) implements class_8710 {
    public static final byte CLEAR = 0;
    public static final byte SET = 1;

    public static final class_8710.class_9154<MiningTargetPayload> TYPE =
        new class_8710.class_9154<>(ModIds.id(AmethystFarmMod.MOD_ID, "mining_target"));

    public static final class_9139<class_2540, MiningTargetPayload> CODEC = class_9139.method_56437(
        (buf, payload) -> {
            buf.method_52997(payload.action());
            buf.method_10804(payload.fakeEntityId());
            if (payload.action() == SET) {
                BlockPosNetwork.writeBlockPos(buf, payload.target());
            }
        },
        buf -> {
            byte action = buf.readByte();
            int entityId = buf.method_10816();
            class_2338 target = action == SET ? BlockPosNetwork.readBlockPos(buf) : class_2338.field_10980;
            return new MiningTargetPayload(action, entityId, target);
        }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static MiningTargetPayload of(int fakeEntityId, class_2338 target) {
        return new MiningTargetPayload(SET, fakeEntityId, target);
    }

    public static MiningTargetPayload cleared(int fakeEntityId) {
        return new MiningTargetPayload(CLEAR, fakeEntityId, class_2338.field_10980);
    }
}
