package com.zsj.amethystfarm.network;

import com.zsj.amethystfarm.AmethystFarmMod;
import com.zsj.amethystfarm.util.ModIds;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record PreviewSyncPayload(
    byte action,
    int fakeEntityId,
    class_2338 origin,
    class_2338 extent,
    List<CrystalEntry> added,
    List<class_2338> removedRelative
) implements class_8710 {
    public static final byte CLEAR = 0;
    public static final byte FULL = 1;
    public static final byte DELTA = 2;

    public static final class_8710.class_9154<PreviewSyncPayload> TYPE =
        new class_8710.class_9154<>(ModIds.id(AmethystFarmMod.MOD_ID, "preview_sync"));

    public record CrystalEntry(int dx, int dy, int dz, boolean mature) {}

    public static final class_9139<class_2540, PreviewSyncPayload> CODEC = class_9139.method_56437(
        PreviewSyncPayload::encode,
        PreviewSyncPayload::decode
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static PreviewSyncPayload cleared(int fakeEntityId) {
        return new PreviewSyncPayload(CLEAR, fakeEntityId, class_2338.field_10980, class_2338.field_10980, List.of(), List.of());
    }

    public static PreviewSyncPayload full(int fakeEntityId, class_2338 origin, class_2338 extent, List<CrystalEntry> crystals) {
        return new PreviewSyncPayload(FULL, fakeEntityId, origin, extent, crystals, List.of());
    }

    public static PreviewSyncPayload delta(
        int fakeEntityId,
        class_2338 origin,
        List<CrystalEntry> added,
        List<class_2338> removedRelative
    ) {
        return new PreviewSyncPayload(DELTA, fakeEntityId, origin, class_2338.field_10980, added, removedRelative);
    }

    private static void encode(class_2540 buf, PreviewSyncPayload payload) {
        buf.method_52997(payload.action());
        buf.method_10804(payload.fakeEntityId());
        switch (payload.action()) {
            case FULL -> {
                BlockPosNetwork.writeBlockPos(buf, payload.origin());
                BlockPosNetwork.writeBlockPos(buf, payload.extent());
                writeEntries(buf, payload.added());
            }
            case DELTA -> {
                BlockPosNetwork.writeBlockPos(buf, payload.origin());
                writeRelativeList(buf, payload.removedRelative());
                writeEntries(buf, payload.added());
            }
            default -> {}
        }
    }

    private static PreviewSyncPayload decode(class_2540 buf) {
        byte action = buf.readByte();
        int entityId = buf.method_10816();
        return switch (action) {
            case FULL -> new PreviewSyncPayload(
                FULL,
                entityId,
                BlockPosNetwork.readBlockPos(buf),
                BlockPosNetwork.readBlockPos(buf),
                readEntries(buf),
                List.of()
            );
            case DELTA -> {
                class_2338 origin = BlockPosNetwork.readBlockPos(buf);
                List<class_2338> removed = readRelativeList(buf);
                List<CrystalEntry> added = readEntries(buf);
                yield new PreviewSyncPayload(DELTA, entityId, origin, class_2338.field_10980, added, removed);
            }
            default -> cleared(entityId);
        };
    }

    private static void writeEntries(class_2540 buf, List<CrystalEntry> entries) {
        buf.method_10804(entries.size());
        for (CrystalEntry entry : entries) {
            buf.method_10804(entry.dx());
            buf.method_10804(entry.dy());
            buf.method_10804(entry.dz());
            buf.method_52964(entry.mature());
        }
    }

    private static List<CrystalEntry> readEntries(class_2540 buf) {
        int count = buf.method_10816();
        List<CrystalEntry> entries = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            entries.add(new CrystalEntry(
                buf.method_10816(),
                buf.method_10816(),
                buf.method_10816(),
                buf.readBoolean()
            ));
        }
        return entries;
    }

    private static void writeRelativeList(class_2540 buf, List<class_2338> relative) {
        buf.method_10804(relative.size());
        for (class_2338 rel : relative) {
            buf.method_10804(rel.method_10263());
            buf.method_10804(rel.method_10264());
            buf.method_10804(rel.method_10260());
        }
    }

    private static List<class_2338> readRelativeList(class_2540 buf) {
        int count = buf.method_10816();
        List<class_2338> relative = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            relative.add(new class_2338(buf.method_10816(), buf.method_10816(), buf.method_10816()));
        }
        return relative;
    }
}
