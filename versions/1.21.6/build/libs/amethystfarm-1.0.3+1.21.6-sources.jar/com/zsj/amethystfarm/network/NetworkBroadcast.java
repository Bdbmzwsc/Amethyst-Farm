package com.zsj.amethystfarm.network;

import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

public final class NetworkBroadcast {
    private NetworkBroadcast() {}

    public static void sendToWorld(class_3218 level, class_8710 payload, class_8710.class_9154<?> type) {
        for (class_3222 player : PlayerLookup.world(level)) {
            sendToPlayer(player, payload, type);
        }
    }

    public static void sendToPlayer(class_3222 player, class_8710 payload, class_8710.class_9154<?> type) {
        if (ServerPlayNetworking.canSend(player, type)) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    public static void sendToWorldNear(
        class_3218 level,
        class_2338 center,
        double range,
        class_8710 payload,
        class_8710.class_9154<?> type
    ) {
        double rangeSqr = range * range;
        class_243 point = class_243.method_24953(center);
        for (class_3222 player : PlayerLookup.world(level)) {
            if (player.method_51469().method_27983() != level.method_27983()) {
                continue;
            }
            if (player.method_33571().method_1025(point) > rangeSqr) {
                continue;
            }
            sendToPlayer(player, payload, type);
        }
    }
}
