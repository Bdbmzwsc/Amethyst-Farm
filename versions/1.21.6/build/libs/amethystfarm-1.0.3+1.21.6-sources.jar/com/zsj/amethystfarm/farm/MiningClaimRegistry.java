package com.zsj.amethystfarm.farm;

import com.zsj.amethystfarm.config.AmethystFarmSettings;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_5321;

public final class MiningClaimRegistry {
    private record ClaimKey(class_5321<class_1937> dimension, long blockPos) {}

    private static final Map<ClaimKey, UUID> CLAIMS = new ConcurrentHashMap<>();
    private static final Map<UUID, ClaimKey> ACTIVE_CLAIM_BY_BOT = new ConcurrentHashMap<>();

    private MiningClaimRegistry() {}

    public static List<class_2338> filterAvailable(class_3222 bot, List<class_2338> crystals) {
        if (!AmethystFarmSettings.multiBotMining) {
            return crystals;
        }
        class_5321<class_1937> dimension = bot.method_51469().method_27983();
        return crystals.stream()
            .filter(pos -> isAvailable(dimension, bot.method_5667(), pos))
            .toList();
    }

    public static boolean isAvailable(class_5321<class_1937> dimension, UUID botId, class_2338 pos) {
        if (!AmethystFarmSettings.multiBotMining) {
            return true;
        }
        UUID owner = CLAIMS.get(new ClaimKey(dimension, pos.method_10063()));
        return owner == null || owner.equals(botId);
    }

    public static boolean tryClaim(class_3222 bot, class_2338 pos) {
        if (!AmethystFarmSettings.multiBotMining) {
            release(bot);
            return true;
        }
        class_5321<class_1937> dimension = bot.method_51469().method_27983();
        ClaimKey key = new ClaimKey(dimension, pos.method_10063());
        UUID botId = bot.method_5667();

        release(bot);

        UUID existing = CLAIMS.get(key);
        if (existing != null && !existing.equals(botId)) {
            return false;
        }

        CLAIMS.put(key, botId);
        ACTIVE_CLAIM_BY_BOT.put(botId, key);
        return true;
    }

    public static void release(class_3222 bot) {
        if (!AmethystFarmSettings.multiBotMining) {
            return;
        }
        ClaimKey key = ACTIVE_CLAIM_BY_BOT.remove(bot.method_5667());
        if (key != null) {
            CLAIMS.remove(key, bot.method_5667());
        }
    }

    public static void releaseAllForBot(UUID botId) {
        ClaimKey key = ACTIVE_CLAIM_BY_BOT.remove(botId);
        if (key != null) {
            CLAIMS.remove(key, botId);
        }
    }

    public static int activeClaimCount() {
        return CLAIMS.size();
    }
}
