package com.zsj.amethystfarm.farm;

import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5542;

public final class AmethystCrystalHelper {
    public static final List<class_2248> HARVESTABLE_BLOCKS = List.of(
        class_2246.field_27164,
        class_2246.field_27163,
        class_2246.field_27162,
        class_2246.field_27161
    );

    private AmethystCrystalHelper() {}

    public static boolean isHarvestableCrystal(class_2680 state) {
        return HARVESTABLE_BLOCKS.stream().anyMatch(state::method_27852);
    }

    public static boolean isMatureCluster(class_2680 state) {
        return state.method_27852(class_2246.field_27161);
    }

    public static boolean isAttachedToBuddingAmethyst(class_2680 state, class_1937 level, class_2338 pos) {
        if (!isHarvestableCrystal(state)) {
            return false;
        }
        var facing = state.method_11654(class_5542.field_27087);
        return level.method_8320(pos.method_10093(facing.method_10153())).method_27852(class_2246.field_27160);
    }

    public static boolean isOnBuddingSide(class_2680 state) {
        if (!state.method_28498(class_5542.field_27087)) {
            return false;
        }
        class_2350 facing = state.method_11654(class_5542.field_27087);
        return facing.method_10166() != class_2350.class_2351.field_11052;
    }

    public static boolean isHarvestableCrystal(class_2680 state, net.minecraft.class_3218 level, class_2338 pos) {
        return isAttachedToBuddingAmethyst(state, level, pos);
    }

    public static boolean matchesHarvestWhitelist(
        class_2680 state,
        class_1937 level,
        class_2338 pos,
        HarvestWhitelist whitelist
    ) {
        if (!isAttachedToBuddingAmethyst(state, level, pos)) {
            return false;
        }
        if (whitelist.isSidesOnly() && !isOnBuddingSide(state)) {
            return false;
        }
        if (state.method_27852(class_2246.field_27164)) {
            return whitelist.isSmallBud();
        }
        if (state.method_27852(class_2246.field_27163)) {
            return whitelist.isMediumBud();
        }
        if (state.method_27852(class_2246.field_27162)) {
            return whitelist.isLargeBud();
        }
        if (state.method_27852(class_2246.field_27161)) {
            return whitelist.isCluster();
        }
        return false;
    }

    public static boolean matchesHarvestWhitelist(
        class_2680 state,
        net.minecraft.class_3218 level,
        class_2338 pos,
        HarvestWhitelist whitelist
    ) {
        return matchesHarvestWhitelist(state, (class_1937) level, pos, whitelist);
    }

    public static int getGrowthPriority(class_2680 state) {
        if (state.method_27852(class_2246.field_27161)) {
            return 4;
        }
        if (state.method_27852(class_2246.field_27162)) {
            return 3;
        }
        if (state.method_27852(class_2246.field_27163)) {
            return 2;
        }
        if (state.method_27852(class_2246.field_27164)) {
            return 1;
        }
        return 0;
    }

    public static java.util.Comparator<class_2338> harvestPriorityComparator(net.minecraft.class_3218 level) {
        return java.util.Comparator
            .comparingInt((class_2338 pos) -> -getGrowthPriority(level.method_8320(pos)))
            .thenComparingDouble(pos -> 0);
    }
}
