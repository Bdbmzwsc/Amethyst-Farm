package com.zsj.amethystfarm.client.preview;

import com.zsj.amethystfarm.client.render.CachedCrystalOutline;
import com.zsj.amethystfarm.farm.AmethystCrystalHelper;
import com.zsj.amethystfarm.network.MiningTargetPayload;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class ClientMiningCache {
    private static final Map<Integer, CachedCrystalOutline> MINING_TARGETS = new ConcurrentHashMap<>();

    private ClientMiningCache() {}

    public static void apply(MiningTargetPayload payload) {
        if (payload.action() == MiningTargetPayload.CLEAR) {
            MINING_TARGETS.remove(payload.fakeEntityId());
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }

        class_2338 pos = payload.target();
        class_2680 state = client.field_1687.method_8320(pos);
        if (!AmethystCrystalHelper.isHarvestableCrystal(state)) {
            MINING_TARGETS.remove(payload.fakeEntityId());
            return;
        }

        class_265 shape = state.method_26218(client.field_1687, pos);
        if (shape.method_1110()) {
            MINING_TARGETS.remove(payload.fakeEntityId());
            return;
        }

        MINING_TARGETS.put(payload.fakeEntityId(), new CachedCrystalOutline(
            pos, shape.method_1107(), AmethystCrystalHelper.isMatureCluster(state)
        ));
    }

    public static Map<Integer, CachedCrystalOutline> all() {
        purgeMissingEntities();
        return MINING_TARGETS;
    }

    public static boolean isEmpty() {
        return MINING_TARGETS.isEmpty();
    }

    private static void purgeMissingEntities() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }
        Iterator<Map.Entry<Integer, CachedCrystalOutline>> iterator = MINING_TARGETS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, CachedCrystalOutline> entry = iterator.next();
            if (client.field_1687.method_8469(entry.getKey()) == null) {
                iterator.remove();
            }
        }
    }
}
