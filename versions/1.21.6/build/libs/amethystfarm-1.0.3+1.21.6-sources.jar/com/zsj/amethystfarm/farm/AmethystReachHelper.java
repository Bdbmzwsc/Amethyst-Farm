package com.zsj.amethystfarm.farm;

import com.zsj.amethystfarm.config.AmethystFarmSettings;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;

public final class AmethystReachHelper {
    private AmethystReachHelper() {}

    public static double getMiningReach(class_3222 player) {
        if (AmethystFarmSettings.miningReach > 0) {
            return AmethystFarmSettings.miningReach;
        }
        return player.field_13974.method_14257().method_8386() ? 5.0D : 4.5D;
    }

    public static double getReachSquared(class_3222 player) {
        double reach = getMiningReach(player);
        return reach * reach;
    }

    public static boolean isWithinReach(class_3222 player, class_2338 pos) {
        return player.method_5707(class_243.method_24953(pos)) <= getReachSquared(player);
    }

    public static List<class_2338> filterInReach(class_3222 player, List<class_2338> crystals) {
        double reachSqr = getReachSquared(player);
        return crystals.stream()
            .filter(pos -> player.method_5707(class_243.method_24953(pos)) <= reachSqr)
            .toList();
    }
}
