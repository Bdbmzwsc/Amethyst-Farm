package com.zsj.amethystfarm.gui;

import net.minecraft.class_3917;

public final class AmethystFarmMenuTypes {
    public static class_3917<AmethystFarmMenu> AMETHYST_FARM_MENU;

    private AmethystFarmMenuTypes() {}
}
