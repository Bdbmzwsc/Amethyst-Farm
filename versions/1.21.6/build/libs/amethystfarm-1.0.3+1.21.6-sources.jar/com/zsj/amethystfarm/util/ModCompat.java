package com.zsj.amethystfarm.util;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;

public final class ModCompat {
    private ModCompat() {}

    public static String profileName(GameProfile profile) {
        //? if >=1.21.9 {
        /*return profile.name();
        *///?} else {
        return profile.getName();
         //?}
    }

    public static MinecraftServer serverOf(class_3222 player) {
        //? if >=1.21.9 {
        /*return player.level().getServer();
        *///?} else {
        return player.method_5682();
         //?}
    }

    public static String dimensionKey(class_5321<class_1937> dimension) {
        //? if >=1.21.11 {
        /*return dimension.identifier().toString();
        *///?} else {
        return dimension.method_29177().toString();
         //?}
    }
}
