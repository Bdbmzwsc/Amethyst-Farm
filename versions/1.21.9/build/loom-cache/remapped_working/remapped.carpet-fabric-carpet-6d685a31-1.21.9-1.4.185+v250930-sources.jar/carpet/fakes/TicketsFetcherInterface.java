package carpet.fakes;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.List;
import net.minecraft.server.level.Ticket;

public interface TicketsFetcherInterface
{
    Long2ObjectOpenHashMap<List<Ticket>> getTicketsByPosition();
}
