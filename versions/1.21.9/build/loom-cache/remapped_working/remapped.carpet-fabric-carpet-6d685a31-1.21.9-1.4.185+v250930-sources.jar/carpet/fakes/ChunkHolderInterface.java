package carpet.fakes;

import java.util.concurrent.CompletableFuture;

public interface ChunkHolderInterface
{
    //CompletableFuture<ChunkResult<ChunkAccess>> setDefaultProtoChunk(ChunkPos chpos, BlockableEventLoop<Runnable> executor, ServerLevel world);
}
