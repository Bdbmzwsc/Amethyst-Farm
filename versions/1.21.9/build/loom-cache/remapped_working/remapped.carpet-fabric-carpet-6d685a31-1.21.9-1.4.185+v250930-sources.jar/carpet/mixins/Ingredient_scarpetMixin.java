package carpet.mixins;

import net.minecraft.world.item.crafting.Ingredient;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Ingredient.class)
public class Ingredient_scarpetMixin// implements IngredientInterface
{

}
