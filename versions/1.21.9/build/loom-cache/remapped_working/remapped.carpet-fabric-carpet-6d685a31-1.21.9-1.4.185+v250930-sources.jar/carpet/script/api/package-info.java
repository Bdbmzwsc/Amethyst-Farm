@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package carpet.script.api;

import javax.annotation.ParametersAreNonnullByDefault;
