@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package carpet.script.utils.shapes;

import javax.annotation.ParametersAreNonnullByDefault;
