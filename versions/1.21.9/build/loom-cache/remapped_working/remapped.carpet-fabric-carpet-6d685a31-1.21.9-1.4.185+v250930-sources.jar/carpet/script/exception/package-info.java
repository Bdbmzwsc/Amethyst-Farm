@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package carpet.script.exception;

import javax.annotation.ParametersAreNonnullByDefault;
