@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package carpet.script.utils;

import javax.annotation.ParametersAreNonnullByDefault;
