@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package carpet.script.argument;

import javax.annotation.ParametersAreNonnullByDefault;
