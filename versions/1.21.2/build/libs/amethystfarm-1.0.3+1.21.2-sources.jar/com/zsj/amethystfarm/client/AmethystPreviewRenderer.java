package com.zsj.amethystfarm.client;

import com.zsj.amethystfarm.client.preview.ClientMiningCache;
import com.zsj.amethystfarm.client.preview.ClientPreviewCache;
import com.zsj.amethystfarm.client.render.CachedCrystalOutline;
import com.zsj.amethystfarm.client.render.ClientRenderConfig;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

public final class AmethystPreviewRenderer {
    private AmethystPreviewRenderer() {}

    public static void register() {
        //? if >=1.21.10 {
        /*net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.END_MAIN
            .register(AmethystPreviewRenderer::renderModern);
        *///?} else if <1.21.9 {
        net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.LAST
            .register(AmethystPreviewRenderer::renderLegacy);
         //?}
    }

    //? if >=1.21.10 {
    /*private static void renderModern(net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext context) {
        if (ClientPreviewCache.isEmpty() && ClientMiningCache.isEmpty()) {
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.level == null || client.player == null) {
            return;
        }

        var consumers = context.consumers();
        if (consumers == null) {
            return;
        }

        Vec3 camera = context.worldState().cameraRenderState.pos;
        double maxDistSqr = ClientRenderConfig.maxRenderDistanceSqr();
        PoseStack matrices = context.matrices();
        //? if >=1.21.11 {
        /^VertexConsumer lines = consumers.getBuffer(net.minecraft.client.renderer.rendertype.RenderTypes.lines());
        ^///?} else {
        VertexConsumer lines = consumers.getBuffer(net.minecraft.client.renderer.RenderType.lines());
         //?}

        matrices.pushPose();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        drawModernScene(matrices, lines, camera, maxDistSqr);
        matrices.popPose();
    }

    private static void drawModernScene(PoseStack matrices, VertexConsumer lines, Vec3 camera, double maxDistSqr) {
        for (var entry : ClientPreviewCache.all().entrySet()) {
            ClientPreviewCache.CrystalPreview preview = entry.getValue();

            if (ClientRenderConfig.drawRegionBox) {
                AABB world = regionBox(preview);
                if (world.getCenter().distanceToSqr(camera) <= maxDistSqr * 4) {
                    //? if >=1.21.11 {
                    /^net.minecraft.client.renderer.ShapeRenderer.renderShape(
                        matrices, lines, net.minecraft.world.phys.shapes.Shapes.create(world),
                        0, 0, 0, packColor(0.6f, 0.2f, 1.0f, 0.6f), 1.0f
                    );
                    ^///?} else if >=1.21.10 {
                    /^net.minecraft.client.renderer.ShapeRenderer.renderLineBox(
                        matrices.last(), lines, world, 0.6f, 0.2f, 1.0f, 0.6f
                    );
                    ^///?} else {
                    net.minecraft.client.renderer.ShapeRenderer.renderLineBox(
                        matrices, lines, world, 0.6f, 0.2f, 1.0f, 0.6f
                    );
                     //?}
                }
            }

            for (CachedCrystalOutline outline : selectVisible(preview.crystalList(), camera, maxDistSqr,
                ClientRenderConfig.maxCrystalOutlines)) {
                drawModernOutline(matrices, lines, outline,
                    outline.mature() ? 0.25f : 0.75f,
                    outline.mature() ? 1.0f : 0.45f,
                    outline.mature() ? 0.45f : 1.0f);
            }
        }

        for (CachedCrystalOutline outline : ClientMiningCache.all().values()) {
            if (outline.distanceSquaredTo(camera) <= maxDistSqr) {
                drawModernOutline(matrices, lines, outline, 1.0f, 0.15f, 0.15f);
            }
        }
    }

    private static void drawModernOutline(PoseStack matrices, VertexConsumer lines, CachedCrystalOutline outline,
                                          float r, float g, float b) {
        AABB box = outline.localBounds().move(outline.pos()).inflate(0.01);
        //? if >=1.21.11 {
        /^net.minecraft.client.renderer.ShapeRenderer.renderShape(
            matrices, lines, net.minecraft.world.phys.shapes.Shapes.create(box),
            0, 0, 0, packColor(r, g, b, 0.9f), 1.0f
        );
        ^///?} else if >=1.21.10 {
        /^net.minecraft.client.renderer.ShapeRenderer.renderLineBox(matrices.last(), lines, box, r, g, b, 0.9f);
        ^///?} else {
        net.minecraft.client.renderer.ShapeRenderer.renderLineBox(matrices, lines, box, r, g, b, 0.9f);
         //?}
    }
    *///?} else if <1.21.9 {
    private static void renderLegacy(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (ClientPreviewCache.isEmpty() && ClientMiningCache.isEmpty()) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) {
            return;
        }

        var consumers = context.consumers();
        if (consumers == null) {
            return;
        }

        class_243 camera = context.camera().method_19326();
        double maxDistSqr = ClientRenderConfig.maxRenderDistanceSqr();
        class_4587 matrices = context.matrixStack();
        class_4588 lines = consumers.getBuffer(net.minecraft.class_1921.method_23594());

        for (var entry : ClientPreviewCache.all().entrySet()) {
            ClientPreviewCache.CrystalPreview preview = entry.getValue();

            if (ClientRenderConfig.drawRegionBox) {
                class_238 world = regionBox(preview);
                if (world.method_1005().method_1025(camera) <= maxDistSqr * 4) {
                    class_238 region = world.method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
                    //? if >=1.21.4 {
                    /*net.minecraft.client.renderer.ShapeRenderer.renderLineBox(
                        matrices, lines, region, 0.6f, 0.2f, 1.0f, 0.6f
                    );
                    *///?}
                }
            }

            for (CachedCrystalOutline outline : selectVisible(preview.crystalList(), camera, maxDistSqr,
                ClientRenderConfig.maxCrystalOutlines)) {
                drawLegacyOutline(matrices, lines, outline, camera,
                    outline.mature() ? 0.25f : 0.75f,
                    outline.mature() ? 1.0f : 0.45f,
                    outline.mature() ? 0.45f : 1.0f);
            }
        }

        for (CachedCrystalOutline outline : ClientMiningCache.all().values()) {
            if (outline.distanceSquaredTo(camera) > maxDistSqr) {
                continue;
            }
            drawLegacyOutline(matrices, lines, outline, camera, 1.0f, 0.15f, 0.15f);
        }
    }

    private static void drawLegacyOutline(class_4587 matrices, class_4588 lines, CachedCrystalOutline outline,
                                          class_243 camera, float r, float g, float b) {
        //? if >=1.21.4 {
        /*AABB box = outline.localBounds()
            .move(outline.pos())
            .move(-camera.x, -camera.y, -camera.z)
            .inflate(0.01);
        net.minecraft.client.renderer.ShapeRenderer.renderLineBox(matrices, lines, box, r, g, b, 0.9f);
        *///?}
    }
    //?}

    private static class_238 regionBox(ClientPreviewCache.CrystalPreview preview) {
        class_2338 min = new class_2338(
            Math.min(preview.pos1().method_10263(), preview.pos2().method_10263()),
            Math.min(preview.pos1().method_10264(), preview.pos2().method_10264()),
            Math.min(preview.pos1().method_10260(), preview.pos2().method_10260())
        );
        class_2338 max = new class_2338(
            Math.max(preview.pos1().method_10263(), preview.pos2().method_10263()),
            Math.max(preview.pos1().method_10264(), preview.pos2().method_10264()),
            Math.max(preview.pos1().method_10260(), preview.pos2().method_10260())
        );
        return new class_238(min.method_10263(), min.method_10264(), min.method_10260(), max.method_10263() + 1, max.method_10264() + 1, max.method_10260() + 1);
    }

    private static List<CachedCrystalOutline> selectVisible(
        List<CachedCrystalOutline> crystals,
        class_243 camera,
        double maxDistSqr,
        int limit
    ) {
        if (crystals.isEmpty()) {
            return List.of();
        }

        List<CachedCrystalOutline> inRange = new ArrayList<>(Math.min(limit, crystals.size()));
        for (CachedCrystalOutline outline : crystals) {
            if (outline.distanceSquaredTo(camera) <= maxDistSqr) {
                inRange.add(outline);
            }
        }

        if (inRange.size() <= limit) {
            return inRange;
        }

        inRange.sort(Comparator
            .comparingDouble((CachedCrystalOutline o) -> o.distanceSquaredTo(camera))
            .thenComparingInt(o -> o.pos().method_10263())
            .thenComparingInt(o -> o.pos().method_10264())
            .thenComparingInt(o -> o.pos().method_10260()));
        return List.copyOf(inRange.subList(0, limit));
    }

    private static int packColor(float r, float g, float b, float a) {
        return ((int) (a * 255.0F) << 24)
            | ((int) (r * 255.0F) << 16)
            | ((int) (g * 255.0F) << 8)
            | (int) (b * 255.0F);
    }
}
